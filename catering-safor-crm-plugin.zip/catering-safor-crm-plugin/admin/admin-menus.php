<?php
if (!defined('ABSPATH')) exit;

function cscrm_admin_menus() {
    global $wpdb;

    $tabla_menus = $wpdb->prefix . 'catering_menus';
    $tabla_prov  = $wpdb->prefix . 'catering_proveedores';

    /* =========================
       CREAR MENÚ
    ========================== */
    if (isset($_POST['cscrm_crear_menu'])) {
        $wpdb->insert($tabla_menus, [
            'proveedor_id' => intval($_POST['proveedor_id']),
            'nombre_menu'  => sanitize_text_field($_POST['nombre_menu']),
            'precio_menu'  => floatval($_POST['precio_menu']),
            'entrantes'    => sanitize_textarea_field($_POST['entrantes']),
            'principal'    => sanitize_textarea_field($_POST['principal']),
            'postre'       => sanitize_textarea_field($_POST['postre']),
            'bebidas'      => sanitize_textarea_field($_POST['bebidas']),
            'disponible'   => 1
        ]);
        echo '<div class="updated notice"><p>Menú creado correctamente.</p></div>';
    }

    /* =========================
       GUARDAR CAMBIOS
    ========================== */
    if (isset($_POST['cscrm_guardar_menu'])) {
        $wpdb->update(
            $tabla_menus,
            [
                'nombre_menu' => sanitize_text_field($_POST['nombre_menu']),
                'precio_menu' => floatval($_POST['precio_menu']),
                'entrantes'   => sanitize_textarea_field($_POST['entrantes']),
                'principal'   => sanitize_textarea_field($_POST['principal']),
                'postre'      => sanitize_textarea_field($_POST['postre']),
                'bebidas'     => sanitize_textarea_field($_POST['bebidas']),
                'disponible'  => isset($_POST['disponible']) ? 1 : 0
            ],
            ['id' => intval($_POST['menu_id'])]
        );
        echo '<div class="updated notice"><p>Menú actualizado.</p></div>';
    }

    /* =========================
       ELIMINAR MENÚ
    ========================== */
    if (isset($_POST['cscrm_eliminar_menu'])) {
        $wpdb->delete($tabla_menus, ['id' => intval($_POST['menu_id'])]);
        echo '<div class="updated notice"><p>Menú eliminado.</p></div>';
    }

    /* =========================
       FILTROS Y ORDEN
    ========================== */
    $precio_filtro = isset($_GET['precio']) ? floatval($_GET['precio']) : '';
    $orden = isset($_GET['orden']) && $_GET['orden'] === 'desc' ? 'DESC' : 'ASC';

    $where = '';
    if ($precio_filtro !== '') {
        $where = $wpdb->prepare("WHERE m.precio_menu = %f", $precio_filtro);
    }

    /* =========================
       DATOS
    ========================== */
    $proveedores = $wpdb->get_results(
        "SELECT id, nombre FROM $tabla_prov ORDER BY nombre ASC"
    );

    $menus = $wpdb->get_results("
        SELECT m.*, p.nombre AS proveedor
        FROM $tabla_menus m
        INNER JOIN $tabla_prov p ON m.proveedor_id = p.id
        $where
        ORDER BY m.precio_menu $orden, p.nombre ASC
    ");

    $menu_editar = null;
    if (isset($_GET['editar'])) {
        $menu_editar = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $tabla_menus WHERE id = %d",
                intval($_GET['editar'])
            )
        );
    }
    ?>

    <div class="wrap">
        <h1>Menús</h1>

        <!-- BOTÓN GRANDE CREAR -->
        <button class="button button-primary button-hero"
                onclick="document.getElementById('form-crear-menu').style.display =
                document.getElementById('form-crear-menu').style.display === 'none' ? 'block' : 'none';">
            ➕ Crear nuevo menú
        </button>

        <!-- FORM CREAR -->
        <div id="form-crear-menu"
             style="display:none; margin-top:20px; max-width:700px; background:#fff; padding:20px; border:1px solid #ccd0d4;">
            <?php if (!$proveedores): ?>
                <p><strong>No hay proveedores disponibles.</strong> Crea un proveedor antes de añadir menús.</p>
            <?php else: ?>
                <form method="post">
                    <p>
                        <label>Proveedor</label><br>
                        <select name="proveedor_id" required style="width:100%;">
                            <?php foreach ($proveedores as $p): ?>
                                <option value="<?= esc_attr($p->id) ?>">
                                    <?= esc_html($p->nombre) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </p>

                    <p>
                        <label>Nombre del menú</label><br>
                        <input type="text" name="nombre_menu" required style="width:100%;">
                    </p>

                    <p>
                        <label>Precio (€)</label><br>
                        <input type="number" step="0.01" name="precio_menu" required>
                    </p>

                    <p><textarea name="entrantes" placeholder="Entrantes"></textarea></p>
                    <p><textarea name="principal" placeholder="Principal"></textarea></p>
                    <p><textarea name="postre" placeholder="Postre"></textarea></p>
                    <p><textarea name="bebidas" placeholder="Bebidas"></textarea></p>

                    <button name="cscrm_crear_menu" class="button button-primary">
                        Guardar menú
                    </button>
                </form>
            <?php endif; ?>
        </div>

        <hr>

        <!-- FILTROS -->
        <form method="get" style="margin-bottom:15px;">
            <input type="hidden" name="page" value="cscrm_menus">

            <input type="number" step="0.01" name="precio"
                   placeholder="Filtrar por precio"
                   value="<?= esc_attr($precio_filtro) ?>">

            <select name="orden">
                <option value="asc" <?= $orden === 'ASC' ? 'selected' : '' ?>>
                    Precio ↑ Ascendente
                </option>
                <option value="desc" <?= $orden === 'DESC' ? 'selected' : '' ?>>
                    Precio ↓ Descendente
                </option>
            </select>

            <button class="button">Aplicar</button>
            <a href="<?= admin_url('admin.php?page=cscrm_menus') ?>" class="button">Limpiar</a>
        </form>

        <p><strong><?= count($menus) ?></strong> menú(s) encontrados.</p>

        <!-- TABLA -->
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>Proveedor</th>
                    <th>Menú</th>
                    <th style="text-align:right;">Precio</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$menus): ?>
                    <tr><td colspan="5">No hay menús.</td></tr>
                <?php endif; ?>

                <?php foreach ($menus as $m): ?>
                    <tr>
                        <td><?= esc_html($m->proveedor) ?></td>
                        <td><?= esc_html($m->nombre_menu) ?></td>
                        <td style="text-align:right; font-weight:600;">
                            <?= esc_html($m->precio_menu) ?> €
                        </td>
                        <td>
                            <?php if ($m->disponible): ?>
                                <span style="color:green; font-weight:600;">Activo</span>
                            <?php else: ?>
                                <span style="color:#999;">Inactivo</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?= admin_url('admin.php?page=cscrm_menus&editar=' . $m->id) ?>"
                               class="button">
                                Editar
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- EDICIÓN -->
        <?php if ($menu_editar): ?>
            <hr>
            <h2>Editar menú: <?= esc_html($menu_editar->nombre_menu) ?></h2>

            <form method="post" style="max-width:600px;">
                <input type="hidden" name="menu_id" value="<?= esc_attr($menu_editar->id) ?>">

                <p>
                    <label>Nombre menú</label><br>
                    <input type="text" name="nombre_menu"
                           value="<?= esc_attr($menu_editar->nombre_menu) ?>" style="width:100%;">
                </p>

                <p>
                    <label>Precio (€)</label><br>
                    <input type="number" step="0.01" name="precio_menu"
                           value="<?= esc_attr($menu_editar->precio_menu) ?>">
                </p>

                <p><textarea name="entrantes"><?= esc_textarea($menu_editar->entrantes) ?></textarea></p>
                <p><textarea name="principal"><?= esc_textarea($menu_editar->principal) ?></textarea></p>
                <p><textarea name="postre"><?= esc_textarea($menu_editar->postre) ?></textarea></p>
                <p><textarea name="bebidas"><?= esc_textarea($menu_editar->bebidas) ?></textarea></p>

                <p>
                    <label>
                        <input type="checkbox" name="disponible"
                            <?= $menu_editar->disponible ? 'checked' : '' ?>>
                        Disponible
                    </label>
                </p>

                <button name="cscrm_guardar_menu" class="button button-primary">
                    Guardar cambios
                </button>

                <button name="cscrm_eliminar_menu"
                        class="button button-secondary"
                        onclick="return confirm('¿Eliminar este menú?');">
                    Eliminar
                </button>
            </form>
        <?php endif; ?>
    </div>
<?php
}
