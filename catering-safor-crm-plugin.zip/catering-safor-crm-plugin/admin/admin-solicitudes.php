<?php
if (!defined('ABSPATH')) exit;

/**
 * =====================================================
 * ADMIN - SOLICITUDES (ESTABLE + DETALLE + ELIMINAR)
 * + RESALTADO DESDE AGENDA
 * =====================================================
 */

if (!function_exists('cscrm_admin_solicitudes')) {
function cscrm_admin_solicitudes() {
    global $wpdb;

    $tabla = $wpdb->prefix . 'catering_solicitudes';
    $highlight = isset($_GET['highlight']) ? intval($_GET['highlight']) : 0;

    // ELIMINAR SOLICITUD
    if (isset($_GET['eliminar'])) {
        $wpdb->delete($tabla, ['id' => intval($_GET['eliminar'])]);
        echo '<div class="updated notice"><p>Solicitud eliminada correctamente.</p></div>';
    }

    // VER DETALLE
    if (isset($_GET['id'])) {
        cscrm_admin_solicitud_detalle(intval($_GET['id']));
        return;
    }

    $solicitudes = $wpdb->get_results("SELECT * FROM $tabla ORDER BY id DESC");
    ?>
    <div class="wrap">
        <h1>Solicitudes de clientes</h1>

        <table class="widefat striped">
            <thead>
                <tr>
                    <th>Cliente</th>
                    <th>Lugar del evento</th>
                    <th>Personas</th>
                    <th>Menú solicitado</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>

                <?php if (empty($solicitudes)) : ?>
                    <tr>
                        <td colspan="6">No hay solicitudes registradas.</td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($solicitudes as $s) :
                    $clase = ($highlight === intval($s->id)) ? 'cscrm-highlight' : '';
                ?>
                    <tr class="<?php echo esc_attr($clase); ?>">
                        <td><?php echo esc_html($s->cliente); ?></td>
                        <td><?php echo esc_html($s->lugar_evento); ?></td>
                        <td><?php echo esc_html($s->personas); ?></td>
                        <td>
                            <?php
                            $precio = '';
                            if (!empty($s->menu_elegido)) {
                                $precio = $s->menu_elegido;
                            } elseif (!empty($s->precio_menu)) {
                                $precio = $s->precio_menu;
                            }
                            echo esc_html($precio) . ' €';
                            ?>
                        </td>
                        <td><?php echo esc_html($s->estado); ?></td>
                        <td>
                            <a class="button button-primary"
                               href="<?php echo esc_url(admin_url('admin.php?page=cscrm_solicitudes&id=' . intval($s->id))); ?>">
                                Ver
                            </a>

                            <a class="button button-secondary"
                               href="<?php echo esc_url(admin_url('admin.php?page=cscrm_solicitudes&eliminar=' . intval($s->id))); ?>"
                               onclick="return confirm('¿Seguro que quieres eliminar esta solicitud?');">
                                Eliminar
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>

            </tbody>
        </table>
    </div>

    <style>
    .cscrm-highlight {
        background-color: #fff3cd !important;
        animation: cscrmFlash 1.5s ease-in-out infinite alternate;
    }

    @keyframes cscrmFlash {
        from { background-color: #fff3cd; }
        to   { background-color: #ffe08a; }
    }
    </style>

    <?php
}}
/**
 * =====================================================
 * DETALLE DE SOLICITUD + SERVICIOS + RECOMENDACIÓN
 * (SIN CAMBIOS)
 * =====================================================
 */
if (!function_exists('cscrm_admin_solicitud_detalle')) {
function cscrm_admin_solicitud_detalle($id) {
    global $wpdb;

    $tabla_sol = $wpdb->prefix . 'catering_solicitudes';
    $tabla_men = $wpdb->prefix . 'catering_menus';
    $tabla_pro = $wpdb->prefix . 'catering_proveedores';

    $sol = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $tabla_sol WHERE id = %d", $id)
    );

    if (!$sol) {
        echo '<div class="wrap"><p>Solicitud no encontrada.</p></div>';
        return;
    }

    $precio_solicitado = 0;
    if (!empty($sol->menu_elegido)) {
        $precio_solicitado = intval($sol->menu_elegido);
    } elseif (!empty($sol->precio_menu)) {
        $precio_solicitado = intval($sol->precio_menu);
    }

    $servicios_map = array(
        'camareros'   => 'Camareros',
        'mesas'       => 'Mesas',
        'sillas'      => 'Sillas',
        'mesas_altas' => 'Mesas altas',
        'manteria'    => 'Mantelería',
        'cuberteria'  => 'Cubertería / Vajilla',
    );

    $servicios_seleccionados = array();
    foreach ($servicios_map as $campo => $label) {
        if (isset($sol->$campo) && intval($sol->$campo) === 1) {
            $servicios_seleccionados[] = $label;
        }
    }
    ?>
    <div class="wrap">
        <h1>Solicitud #<?php echo esc_html($sol->id); ?></h1>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:1000px;">

            <div style="background:#fff; padding:20px; border:1px solid #ccd0d4;">
                <h2>Datos del cliente</h2>
                <p><strong>Cliente:</strong><br><?php echo esc_html($sol->cliente); ?></p>
                <p><strong>Email:</strong><br><?php echo esc_html($sol->email); ?></p>
                <p><strong>Teléfono:</strong><br><?php echo esc_html($sol->telefono); ?></p>
            </div>

            <div style="background:#fff; padding:20px; border:1px solid #ccd0d4;">
                <h2>Evento</h2>
                <p><strong>Lugar:</strong><br><?php echo esc_html($sol->lugar_evento); ?></p>
                <p><strong>Personas:</strong><br><?php echo esc_html($sol->personas); ?></p>
                <p>
                    <strong>Menú solicitado:</strong><br>
                    <span style="font-size:20px; color:#2271b1;">
                        <?php echo esc_html($precio_solicitado); ?> €
                    </span>
                </p>

                <?php if (!empty($sol->evento_datetime)) : ?>
                    <p><strong>Fecha/Hora:</strong><br><?php echo esc_html($sol->evento_datetime); ?></p>
                <?php endif; ?>
            </div>

            <div style="background:#fff; padding:20px; border:1px solid #ccd0d4; grid-column:1 / -1;">
                <h2>Servicios necesarios</h2>

                <?php if (!empty($servicios_seleccionados)) : ?>
                    <ul style="margin:0; padding-left:18px;">
                        <?php foreach ($servicios_seleccionados as $srv) : ?>
                            <li><?php echo esc_html($srv); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php else : ?>
                    <p><em>No se seleccionaron servicios.</em></p>
                <?php endif; ?>
            </div>

        </div>

        <hr style="margin:30px 0;">

        <h2>Proveedores recomendados (por precio)</h2>

        <?php
        if ($precio_solicitado > 0) {

            $menus = $wpdb->get_results(
                "SELECT 
                    m.nombre_menu,
                    m.precio_menu,
                    p.nombre AS proveedor
                 FROM $tabla_men m
                 LEFT JOIN $tabla_pro p ON p.id = m.proveedor_id"
            );

            if ($menus) {

                foreach ($menus as $m) {
                    $m->diferencia = abs(intval($m->precio_menu) - $precio_solicitado);
                }

                usort($menus, function ($a, $b) {
                    if ($a->diferencia == $b->diferencia) {
                        return $a->precio_menu <=> $b->precio_menu;
                    }
                    return $a->diferencia <=> $b->diferencia;
                });

                $recomendados = array_slice($menus, 0, 2);

                foreach ($recomendados as $r) : ?>
                    <div style="padding:15px; margin-bottom:10px;
                                background:#f6f7f7; border-left:4px solid #2271b1;">
                        <strong><?php echo esc_html($r->proveedor); ?></strong><br>
                        Menú: <?php echo esc_html($r->nombre_menu); ?><br>
                        Precio: <strong><?php echo esc_html($r->precio_menu); ?> €</strong>
                    </div>
                <?php endforeach;

            } else {
                echo '<p><em>No hay menús registrados.</em></p>';
            }

        } else {
            echo '<p><em>La solicitud no tiene precio definido.</em></p>';
        }
        ?>

        <br>
        <a href="<?php echo esc_url(admin_url('admin.php?page=cscrm_solicitudes')); ?>" class="button">
            Volver al listado
        </a>
    </div>
    <?php
}}
