<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('cscrm_admin_catering_safor_moderno')) {
function cscrm_admin_catering_safor_moderno() {

    echo '<div class="wrap">';
    echo '<h1>Gestión Catering Safor (Moderna)</h1>';
    echo '<p style="opacity:.7">Versión de pruebas. La gestión original no se ha tocado.</p>';
    echo '</div>';

    if (function_exists('cscrm_admin_catering_safor')) {
        cscrm_admin_catering_safor();
    } else {
        echo '<div class="notice notice-error"><p>No se encontró la función cscrm_admin_catering_safor().</p></div>';
    }
}
}
