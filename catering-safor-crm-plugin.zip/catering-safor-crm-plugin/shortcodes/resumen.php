<?php
add_shortcode('catering_resumen',function($a){
 global $wpdb;
 $id=intval($a['id']);
 $s=$wpdb->get_row("SELECT * FROM {$wpdb->prefix}catering_solicitudes WHERE id=$id");
 if(!$s) return 'No encontrada';
 $p=cscrm_autoselect_proveedor($s->menu_elegido,$s->personas);
 if(!$p) return 'No hay proveedor compatible';
 return '<h3>Proveedor recomendado: '.$p[0]->nombre.'</h3>';
});
