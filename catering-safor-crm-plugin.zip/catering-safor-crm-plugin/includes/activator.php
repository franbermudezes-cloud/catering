<?php
if (!defined('ABSPATH')) exit;

function cscrm_activate(){
    // Crea/actualiza tablas
    if (function_exists('cscrm_create_tables')) {
        cscrm_create_tables();
    }
    if (defined('CSCRM_DB_VERSION')) {
        update_option('cscrm_db_version', CSCRM_DB_VERSION);
    }
}
