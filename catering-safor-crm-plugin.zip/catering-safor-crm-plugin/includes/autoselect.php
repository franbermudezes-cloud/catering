<?php
function cscrm_autoselect_proveedor($menu,$personas){
 global $wpdb;
 return $wpdb->get_results($wpdb->prepare(
 "SELECT p.* FROM {$wpdb->prefix}catering_proveedores p
 JOIN {$wpdb->prefix}catering_capacidades c ON p.id=c.proveedor_id
 JOIN {$wpdb->prefix}catering_menus m ON p.id=m.proveedor_id
 WHERE m.precio_menu=%d AND m.disponible=1
 AND c.disponible=1 AND %d>=c.rango_min
 AND (%d<=c.rango_max OR c.rango_max IS NULL)",
 $menu,$personas,$personas));
}
