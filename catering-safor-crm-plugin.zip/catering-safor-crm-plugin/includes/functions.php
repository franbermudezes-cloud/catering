<?php
if (!defined('ABSPATH')) exit;

/**
 * =====================================================
 * RECOMENDACIÓN DE PROVEEDORES POR PRECIO
 * =====================================================
 * - Devuelve hasta 2 menús
 * - Usa SOLO el precio
 * - Prioriza el más cercano y más barato
 */

function cscrm_recomendar_proveedores_por_precio($precio, $limite = 2) {
    global $wpdb;

    // Seguridad absoluta
    if (!$precio || !is_numeric($precio)) {
        return [];
    }

    $tabla_menus = $wpdb->prefix . 'catering_menus';
    $tabla_prov  = $wpdb->prefix . 'catering_proveedores';

    // CONSULTA DIRECTA (SIN JOIN QUE BLOQUEE)
    $menus = $wpdb->get_results(
        "SELECT 
            m.id,
            m.nombre_menu,
            m.precio_menu,
            m.proveedor_id,
            p.nombre AS proveedor_nombre
         FROM $tabla_menus m
         LEFT JOIN $tabla_prov p ON p.id = m.proveedor_id"
    );

    if (!$menus) {
        return [];
    }

    foreach ($menus as $m) {
        $m->diferencia = abs(intval($m->precio_menu) - intval($precio));
    }

    usort($menus, function ($a, $b) {
        if ($a->diferencia === $b->diferencia) {
            return $a->precio_menu <=> $b->precio_menu;
        }
        return $a->diferencia <=> $b->diferencia;
    });

    return array_slice($menus, 0, $limite);
}
