<?php
if (!defined('ABSPATH')) exit;

function cscrm_create_tables(){
    global $wpdb;

    $c = $wpdb->get_charset_collate();
    require_once(ABSPATH.'wp-admin/includes/upgrade.php');

    // =========================
    // PROVEEDORES
    // =========================
    dbDelta("CREATE TABLE {$wpdb->prefix}catering_proveedores(
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(255),
        telefono VARCHAR(50),
        email VARCHAR(255),
        camareros TINYINT,
        mesas TINYINT,
        sillas TINYINT,
        mesas_altas TINYINT,
        manteria TINYINT,
        cuberteria TINYINT
    ) $c;");

    // =========================
    // CAPACIDADES
    // =========================
    dbDelta("CREATE TABLE {$wpdb->prefix}catering_capacidades(
        id INT AUTO_INCREMENT PRIMARY KEY,
        proveedor_id INT,
        rango_min INT,
        rango_max INT,
        disponible TINYINT
    ) $c;");

    // =========================
    // MENUS
    // =========================
    dbDelta("CREATE TABLE {$wpdb->prefix}catering_menus(
        id INT AUTO_INCREMENT PRIMARY KEY,
        proveedor_id INT,
        precio_menu INT,
        nombre_menu VARCHAR(255),
        entrantes TEXT,
        principal TEXT,
        postre TEXT,
        bebidas TEXT,
        disponible TINYINT,
        precio_por_persona FLOAT
    ) $c;");

    // =========================
    // SOLICITUDES  (AQUÍ ESTÁ LO IMPORTANTE)
    // Incluye TODO lo que ya usas + fechas
    // dbDelta actualiza si la tabla ya existe (no borra datos)
    // =========================
    dbDelta("CREATE TABLE {$wpdb->prefix}catering_solicitudes(
        id INT AUTO_INCREMENT PRIMARY KEY,

        cliente VARCHAR(255) NULL,
        telefono VARCHAR(50) NULL,
        email VARCHAR(255) NULL,

        lugar_evento VARCHAR(255) NULL,
        evento_datetime DATETIME NULL,

        personas INT NULL,

        -- Precio objetivo elegido por el cliente o guardado al asignar
        precio_menu INT NULL,

        -- Campo legado / compatibilidad (lo usabas antes)
        menu_elegido INT NULL,

        -- Gestión interna
        proveedor_id INT NULL,
        estado VARCHAR(30) NULL,

        -- Servicios necesarios
        camareros TINYINT NULL,
        mesas TINYINT NULL,
        sillas TINYINT NULL,
        mesas_altas TINYINT NULL,
        manteria TINYINT NULL,
        cuberteria TINYINT NULL,

        -- Fecha/hora de creación de la solicitud
        created_at DATETIME NULL
    ) $c;");
}
