<?php
if (!defined('ABSPATH')) exit;

add_shortcode('cscrm_solicitud', 'cscrm_shortcode_solicitud_sql_real');

function cscrm_shortcode_solicitud_sql_real() {
    global $wpdb;

    $table = $wpdb->prefix . 'catering_solicitudes';

    // =========================
    // CONFIG
    // =========================
    $brand_name = 'Catering Safor';
    $admin_notify_email = get_option('admin_email'); // o pon tu email fijo

    // Servicios EXACTOS según tu SQL
    $servicios = [
        'camareros'   => 'Camareros',
        'mesas'       => 'Mesas',
        'sillas'      => 'Sillas',
        'mesas_altas' => 'Mesas altas',
        'manteria'    => 'Mantelería',
        'cuberteria'  => 'Cubertería',
    ];

    // Presupuesto por menú (tu desplegable)
    $presupuestos_menu = [20, 30, 40, 50];

    // Textos pro
    $popup_title_success = 'Solicitud enviada';
    $popup_msg_success   = 'Hemos registrado tu solicitud correctamente. En un plazo máximo de 24 horas recibirás una propuesta personalizada para tu catering.';

    $email_subject_client = 'Confirmación de solicitud de catering';
    $email_body_client_tpl = function($data) use ($brand_name) {
        $lines = [];
        $lines[] = "Hola {$data['cliente']},";
        $lines[] = "";
        $lines[] = "Gracias por contactar con {$brand_name}. Hemos recibido tu solicitud y la estamos revisando.";
        $lines[] = "En un plazo máximo de 24 horas te enviaremos una propuesta personalizada con disponibilidad y opciones de menú ajustadas a tu presupuesto.";
        $lines[] = "";
        $lines[] = "Resumen de tu solicitud:";
        $lines[] = "- Fecha y hora: {$data['evento_datetime_hum']}";
        $lines[] = "- Lugar: {$data['lugar_evento']}";
        $lines[] = "- Personas: {$data['personas']}";
        $lines[] = "- Presupuesto por menú: {$data['precio_menu']} €";
        if (!empty($data['servicios_txt'])) $lines[] = "- Servicios adicionales: {$data['servicios_txt']}";
        if (!empty($data['comentario_doc'])) $lines[] = "- Comentarios: {$data['comentario_doc']}";
        $lines[] = "";
        $lines[] = "Si necesitas actualizar algún detalle, responde a este correo y lo ajustamos.";
        $lines[] = "";
        $lines[] = "Un saludo,";
        $lines[] = "{$brand_name}";
        return implode("\n", $lines);
    };

    $email_subject_admin = 'Nueva solicitud recibida (Catering Safor CRM)';
    $email_body_admin_tpl = function($data) use ($brand_name) {
        $lines = [];
        $lines[] = "Nueva solicitud recibida en {$brand_name}:";
        $lines[] = "";
        $lines[] = "Cliente: {$data['cliente']}";
        if (!empty($data['email'])) $lines[] = "Email: {$data['email']}";
        if (!empty($data['telefono'])) $lines[] = "Teléfono: {$data['telefono']}";
        $lines[] = "Fecha y hora: {$data['evento_datetime_hum']}";
        $lines[] = "Lugar: {$data['lugar_evento']}";
        $lines[] = "Personas: {$data['personas']}";
        $lines[] = "Presupuesto por menú: {$data['precio_menu']} €";
        if (!empty($data['servicios_txt'])) $lines[] = "Servicios: {$data['servicios_txt']}";
        if (!empty($data['comentario_doc'])) $lines[] = "Comentarios: {$data['comentario_doc']}";
        $lines[] = "";
        $lines[] = "Gestionar desde el panel de WordPress.";
        return implode("\n", $lines);
    };

    // =========================
    // Procesamiento
    // =========================
    $success = false;
    $error_msg = '';

    if (!empty($_POST['cscrm_solicitud_submit'])) {

        if (empty($_POST['cscrm_nonce']) || !wp_verify_nonce($_POST['cscrm_nonce'], 'cscrm_solicitud_form')) {
            $error_msg = 'Error de seguridad. Recarga la página e inténtalo de nuevo.';
        } else {

            $cliente = sanitize_text_field($_POST['cliente'] ?? '');
            $email = sanitize_email($_POST['email'] ?? '');
            $telefono = sanitize_text_field($_POST['telefono'] ?? '');
            $lugar_evento = sanitize_text_field($_POST['lugar_evento'] ?? '');

            $fecha = sanitize_text_field($_POST['fecha_evento'] ?? ''); // YYYY-MM-DD
            $hora  = sanitize_text_field($_POST['hora_evento'] ?? '');  // HH:MM
            $personas = intval($_POST['personas'] ?? 0);

            $precio_menu = intval($_POST['precio_menu'] ?? 0);
            $comentario_doc = sanitize_textarea_field($_POST['comentario_doc'] ?? '');

            // Servicios tinyint (0/1)
            $serv_vals = [];
            foreach ($servicios as $k => $label) {
                $serv_vals[$k] = !empty($_POST[$k]) ? 1 : 0;
            }

            // Validaciones mínimas
            if ($cliente === '' || $lugar_evento === '' || $fecha === '' || $personas <= 0 || !in_array($precio_menu, $presupuestos_menu, true)) {
                $error_msg = 'Revisa los campos obligatorios: Cliente, Lugar, Fecha, Personas y Presupuesto por menú.';
            } else {

                // Construir datetime (si no hay hora, ponemos 12:00 por defecto)
                if ($hora === '') $hora = '12:00';
                $evento_datetime = $fecha . ' ' . $hora . ':00';

                // Insert EXACTO según tu SQL
                $data = [
                    'cliente'      => $cliente,
                    'telefono'     => ($telefono !== '' ? $telefono : null),
                    'lugar_evento' => $lugar_evento,
                    'precio_menu'  => $precio_menu,
                    'personas'     => $personas,
                    'email'        => ($email !== '' ? $email : null),

                    // estado por defecto Pendiente
                    'estado'       => 'Pendiente',

                    // servicios tinyint
                    'camareros'    => $serv_vals['camareros'],
                    'mesas'        => $serv_vals['mesas'],
                    'sillas'       => $serv_vals['sillas'],
                    'mesas_altas'  => $serv_vals['mesas_altas'],
                    'manteria'     => $serv_vals['manteria'],
                    'cuberteria'   => $serv_vals['cuberteria'],

                    'evento_datetime' => $evento_datetime,
                    'created_at'      => current_time('mysql'),
                    'comentario_doc'  => ($comentario_doc !== '' ? $comentario_doc : null),

                    // IMPORTANTE: dejamos menu_elegido y proveedor_id en NULL (lo decidirá gestión)
                    // 'menu_elegido' => null,
                    // 'proveedor_id' => null,
                ];

                $format = [
                    '%s','%s','%s','%d','%d','%s',
                    '%s',
                    '%d','%d','%d','%d','%d','%d',
                    '%s','%s','%s'
                ];

                $ok = $wpdb->insert($table, $data, $format);

                if ($ok) {
                    $success = true;

                    // Texto de servicios para emails
                    $servicios_txt_arr = [];
                    foreach ($servicios as $k => $label) {
                        if ($serv_vals[$k] === 1) $servicios_txt_arr[] = $label;
                    }
                    $servicios_txt = implode(', ', $servicios_txt_arr);

                    $evento_datetime_hum = $fecha . ' ' . $hora;

                    $payload = [
                        'cliente' => $cliente,
                        'email' => $email,
                        'telefono' => $telefono,
                        'lugar_evento' => $lugar_evento,
                        'precio_menu' => $precio_menu,
                        'personas' => $personas,
                        'servicios_txt' => $servicios_txt,
                        'comentario_doc' => $comentario_doc,
                        'evento_datetime_hum' => $evento_datetime_hum,
                    ];

                    // Email al cliente (si hay email)
                    if ($email !== '') {
                        $from_name  = $brand_name;
                        $from_email = $admin_notify_email;
                        $headers = [
                            'From: ' . $from_name . ' <' . $from_email . '>',
                            'Reply-To: ' . $from_name . ' <' . $from_email . '>',
                            'Content-Type: text/plain; charset=UTF-8'
                        ];
                        @wp_mail($email, $email_subject_client, $email_body_client_tpl($payload), $headers);
                    }

                    // Email interno
                    if (!empty($admin_notify_email)) {
                        $headers2 = ['Content-Type: text/plain; charset=UTF-8'];
                        @wp_mail($admin_notify_email, $email_subject_admin, $email_body_admin_tpl($payload), $headers2);
                    }

                    $_POST = []; // limpia campos tras enviar
                } else {
                    $error_msg = 'No se pudo guardar la solicitud. ' . ($wpdb->last_error ? 'Error: ' . esc_html($wpdb->last_error) : '');
                }
            }
        }
    }

    // =========================
    // Render
    // =========================
    $v = function($key){
        return isset($_POST[$key]) ? esc_attr($_POST[$key]) : '';
    };

    ob_start();
    ?>
    <div class="cscrm-wrap">
        <?php if ($error_msg): ?>
            <div class="cscrm-alert cscrm-alert-error"><?php echo esc_html($error_msg); ?></div>
        <?php endif; ?>

        <div class="cscrm-card">
            <div class="cscrm-card-header">
                <div class="cscrm-title">Solicitar presupuesto</div>
                <div class="cscrm-subtitle">Completa los datos y te enviaremos una propuesta personalizada en menos de 24 horas.</div>
            </div>

            <form method="post" class="cscrm-form">
                <?php wp_nonce_field('cscrm_solicitud_form', 'cscrm_nonce'); ?>

                <div class="cscrm-grid">
                    <div class="cscrm-field">
                        <label>Cliente <span class="cscrm-req">*</span></label>
                        <input type="text" name="cliente" required value="<?php echo $v('cliente'); ?>" placeholder="Nombre y apellidos">
                    </div>

                    <div class="cscrm-field">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo $v('email'); ?>" placeholder="tu@email.com">
                    </div>

                    <div class="cscrm-field">
                        <label>Teléfono</label>
                        <input type="text" name="telefono" value="<?php echo $v('telefono'); ?>" placeholder="600 000 000">
                    </div>

                    <div class="cscrm-field">
                        <label>Lugar del evento <span class="cscrm-req">*</span></label>
                        <input type="text" name="lugar_evento" required value="<?php echo $v('lugar_evento'); ?>" placeholder="Ciudad / ubicación">
                    </div>

                    <div class="cscrm-field">
                        <label>Fecha del evento <span class="cscrm-req">*</span></label>
                        <input type="date" name="fecha_evento" required value="<?php echo $v('fecha_evento'); ?>">
                    </div>

                    <div class="cscrm-field">
                        <label>Hora (opcional)</label>
                        <input type="time" name="hora_evento" value="<?php echo $v('hora_evento'); ?>">
                    </div>

                    <div class="cscrm-field">
                        <label>Personas <span class="cscrm-req">*</span></label>
                        <input type="number" name="personas" min="1" required value="<?php echo $v('personas'); ?>" placeholder="Ej: 66">
                    </div>

                    <div class="cscrm-field">
                        <label>Presupuesto por menú <span class="cscrm-req">*</span></label>
                        <select name="precio_menu" required>
                            <option value="">Selecciona…</option>
                            <?php foreach ($presupuestos_menu as $p): ?>
                                <option value="<?php echo (int)$p; ?>" <?php echo ($v('precio_menu') == (string)$p ? 'selected' : ''); ?>>
                                    <?php echo (int)$p; ?> €
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="cscrm-hint2">Esto nos ayuda a proponerte los menús que mejor encajan.</div>
                    </div>

                    <div class="cscrm-field cscrm-field-full">
                        <label>Servicios adicionales</label>
                        <div class="cscrm-chips">
                            <?php foreach ($servicios as $k => $label): ?>
                                <?php $checked = !empty($_POST[$k]); ?>
                                <label class="cscrm-chip">
                                    <input type="checkbox" name="<?php echo esc_attr($k); ?>" value="1" <?php echo $checked ? 'checked' : ''; ?>>
                                    <span><?php echo esc_html($label); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="cscrm-field cscrm-field-full">
                        <label>Comentarios</label>
                        <textarea name="comentario_doc" rows="4" placeholder="Tipo de evento, preferencias, alergias, horario, etc."><?php
                            echo isset($_POST['comentario_doc']) ? esc_textarea($_POST['comentario_doc']) : '';
                        ?></textarea>
                    </div>
                </div>

                <div class="cscrm-actions">
                    <button type="submit" class="cscrm-btn" name="cscrm_solicitud_submit" value="1">Enviar solicitud</button>
                    <div class="cscrm-hint">Tiempo de respuesta habitual: <strong>menos de 24 horas</strong>.</div>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL -->
    <div class="cscrm-modal" id="cscrmModal" aria-hidden="true">
        <div class="cscrm-modal-backdrop" data-close="1"></div>
        <div class="cscrm-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="cscrmModalTitle">
            <div class="cscrm-modal-icon">✅</div>
            <div class="cscrm-modal-title" id="cscrmModalTitle"><?php echo esc_html($popup_title_success); ?></div>
            <div class="cscrm-modal-text"><?php echo esc_html($popup_msg_success); ?></div>
            <button class="cscrm-btn cscrm-btn-secondary" type="button" id="cscrmModalClose">Cerrar</button>
        </div>
    </div>

    <style>
        .cscrm-wrap{max-width:920px;margin:18px auto;padding:0 12px;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial}
        .cscrm-card{background:#fff;border:1px solid #e9edf3;border-radius:16px;box-shadow:0 6px 18px rgba(16,24,40,.06);overflow:hidden}
        .cscrm-card-header{padding:18px;border-bottom:1px solid #eef2f6}
        .cscrm-title{font-size:20px;font-weight:750}
        .cscrm-subtitle{font-size:13px;color:#667085;margin-top:4px}
        .cscrm-form{padding:16px 18px 18px}
        .cscrm-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
        .cscrm-field{display:flex;flex-direction:column;gap:6px}
        .cscrm-field-full{grid-column:1 / -1}
        .cscrm-field label{font-size:13px;color:#344054}
        .cscrm-req{color:#d92d20;font-weight:700}
        .cscrm-field input,.cscrm-field textarea,.cscrm-field select{
            border:1px solid #d0d5dd;border-radius:12px;padding:10px 12px;font-size:14px;outline:none;
            transition:box-shadow .15s,border-color .15s;background:#fff
        }
        .cscrm-field input:focus,.cscrm-field textarea:focus,.cscrm-field select:focus{border-color:#84c5f4;box-shadow:0 0 0 4px rgba(132,197,244,.25)}
        .cscrm-actions{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:14px}
        .cscrm-btn{
            border:0;border-radius:12px;padding:10px 14px;font-weight:650;cursor:pointer;
            background:#0b5cff;color:#fff;box-shadow:0 8px 18px rgba(11,92,255,.18)
        }
        .cscrm-btn-secondary{background:#f2f4f7;color:#101828;box-shadow:none;border:1px solid #d0d5dd}
        .cscrm-hint{font-size:13px;color:#667085}
        .cscrm-hint2{font-size:12px;color:#667085;margin-top:6px}
        .cscrm-alert{padding:10px 12px;border-radius:12px;margin:10px 0}
        .cscrm-alert-error{background:#ffecec;border:1px solid #f2b8b8;color:#7a1414}

        .cscrm-chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:6px}
        .cscrm-chip{display:inline-flex;align-items:center;gap:8px;border:1px solid #d0d5dd;border-radius:999px;padding:8px 10px;background:#fff;cursor:pointer;user-select:none}
        .cscrm-chip input{width:16px;height:16px;margin:0}
        .cscrm-chip span{font-size:13px;color:#101828}

        .cscrm-modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;z-index:99999}
        .cscrm-modal.is-open{display:flex}
        .cscrm-modal-backdrop{position:absolute;inset:0;background:rgba(16,24,40,.55)}
        .cscrm-modal-dialog{
            position:relative;background:#fff;border-radius:16px;border:1px solid #e9edf3;
            box-shadow:0 24px 60px rgba(16,24,40,.25);
            width:min(520px,92vw);padding:18px;text-align:center
        }
        .cscrm-modal-icon{font-size:30px}
        .cscrm-modal-title{margin-top:6px;font-size:18px;font-weight:800;color:#101828}
        .cscrm-modal-text{margin:10px 0 14px;font-size:14px;color:#475467;line-height:1.4}

        @media (max-width:640px){ .cscrm-grid{grid-template-columns:1fr} }
    </style>

    <script>
        (function(){
            const modal = document.getElementById('cscrmModal');
            if(!modal) return;

            function openModal(){
                modal.classList.add('is-open');
                modal.setAttribute('aria-hidden','false');
                document.body.style.overflow = 'hidden';
            }
            function closeModal(){
                modal.classList.remove('is-open');
                modal.setAttribute('aria-hidden','true');
                document.body.style.overflow = '';
            }

            document.getElementById('cscrmModalClose')?.addEventListener('click', closeModal);
            modal.addEventListener('click', function(e){
                if(e.target && e.target.getAttribute('data-close') === '1') closeModal();
            });
            document.addEventListener('keydown', function(e){
                if(e.key === 'Escape' && modal.classList.contains('is-open')) closeModal();
            });

            <?php if ($success): ?>
                openModal();
            <?php endif; ?>
        })();
    </script>
    <?php
    return ob_get_clean();
}
