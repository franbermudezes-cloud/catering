<?php
/*
Plugin Name: Catering Safor CRM
Plugin URI: https://cateringsafor.com
Description: CRM para gestión de proveedores y solicitudes de catering.
Version: 1.1
Author: Fran Bermúdez
*/

if (!defined('ABSPATH')) exit;

// CONSTANTES
define('CSCRM_PATH', plugin_dir_path(__FILE__));
define('CSCRM_URL', plugin_dir_url(__FILE__));

/**
 * =========================
 * INCLUDES BASE (SEGUROS)
 * =========================
 */

// DB
if (file_exists(CSCRM_PATH . 'includes/db-tables.php')) {
    require_once CSCRM_PATH . 'includes/db-tables.php';
}

// FUNCTIONS
if (file_exists(CSCRM_PATH . 'includes/functions.php')) {
    require_once CSCRM_PATH . 'includes/functions.php';
}

// AUTOSELECT
if (file_exists(CSCRM_PATH . 'includes/autoselect.php')) {
    require_once CSCRM_PATH . 'includes/autoselect.php';
}

// ACTIVATOR
if (file_exists(CSCRM_PATH . 'includes/activator.php')) {
    require_once CSCRM_PATH . 'includes/activator.php';
    if (function_exists('cscrm_activate')) {
        register_activation_hook(__FILE__, 'cscrm_activate');
    }
}

/**
 * =========================
 * ADMIN PANEL
 * =========================
 */
if (is_admin()) {

    $admin_files = [
        'admin/admin-menu.php',
        'admin/admin-proveedores.php',
        'admin/admin-solicitudes.php',
        'admin/admin-menus.php',
        'admin/admin-proveedor-detalle.php',
        'admin/admin-catering-safor.php', // ✅ página principal
        'admin/admin-share-print.php',    // ✅ NUEVO: imprimir/compartir el menú asignado
    ];

    foreach ($admin_files as $file) {
        $path = CSCRM_PATH . $file;
        if (file_exists($path)) {
            require_once $path;
        }
    }
}

/**
 * =========================
 * SHORTCODES
 * =========================
 */
$shortcodes = [
    'shortcodes/solicitud-form.php',
    'shortcodes/resumen.php'
];

foreach ($shortcodes as $file) {
    $path = CSCRM_PATH . $file;
    if (file_exists($path)) {
        require_once $path;
    }
}
