<?php
if (!defined('ABSPATH')) exit;

/**
 * Botones de Imprimir / Compartir / WhatsApp
 * Solo aparecen cuando:
 * - Estás en la página cscrm_catering_safor
 * - Y existe un bloque que parezca el "menú del proveedor" (o tabla/lista con contenido)
 *
 * Importante: NO toca tu lógica de asignar/guardar.
 */

add_action('admin_footer', 'cscrm_inyectar_botones_share_print', 999);

function cscrm_inyectar_botones_share_print() {
    $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
    if ($page !== 'cscrm_catering_safor') return;
    ?>
    <style>
      .cscrm-sharebar{
        margin: 14px 0 0 0;
        display:flex;
        gap:10px;
        flex-wrap:wrap;
        align-items:center;
      }
      .cscrm-sharebar .button{ display:inline-flex; align-items:center; gap:6px; }
      .cscrm-sharebar .cscrm-hint{ opacity:0.75; font-size:12px; }
    </style>

    <script>
    (function(){
      // Detecta el bloque del menú solo cuando ya está pintado (normalmente después de asignar+guardar).
      function findMenuBlock(){
        // Si tu página ya tiene un contenedor con este id, lo usamos (si lo añades en el futuro, perfecto)
        var el = document.getElementById('cscrm-menu-a-compartir');
        if (el && hasEnoughContent(el)) return el;

        // Intento automático: buscamos la "mejor" tabla/lista con contenido dentro de .wrap (admin)
        var wrap = document.querySelector('.wrap') || document.body;

        // 1) Tablas candidatas
        var candidates = Array.from(wrap.querySelectorAll('table')).filter(function(t){
          return hasEnoughContent(t);
        });

        // 2) Listas candidatas
        candidates = candidates.concat(
          Array.from(wrap.querySelectorAll('ul, ol')).filter(function(l){
            return hasEnoughContent(l);
          })
        );

        // 3) Divs candidatos por clases comunes
        candidates = candidates.concat(
          Array.from(wrap.querySelectorAll('.cscrm-menu, .cscrm-menu-proveedor, .menu-proveedor, .menu')).filter(function(d){
            return hasEnoughContent(d);
          })
        );

        if (!candidates.length) return null;

        // Elegimos el candidato con más texto (suele ser el menú)
        var best = candidates.reduce(function(a,b){
          return (textLen(b) > textLen(a)) ? b : a;
        });

        // Lo envolvemos para poder imprimir/compartir solo eso
        var wrapper = document.createElement('div');
        wrapper.id = 'cscrm-menu-a-compartir';
        best.parentNode.insertBefore(wrapper, best);
        wrapper.appendChild(best);

        return wrapper;
      }

      function textLen(el){
        return ((el && (el.innerText || el.textContent)) ? (el.innerText || el.textContent).trim().length : 0);
      }

      function hasEnoughContent(el){
        return textLen(el) >= 30; // umbral para evitar bloques vacíos
      }

      function getMenuText(el){
        if (!el) return '';
        return (el.innerText || el.textContent || '').trim();
      }

      function printBlock(el, title){
        if (!el){
          alert('No he encontrado el menú para imprimir. Si quieres lo ajusto al bloque exacto.');
          return;
        }
        var w = window.open('', '_blank', 'width=900,height=700');
        if (!w){
          alert('El navegador bloqueó la impresión. Permite pop-ups para esta web.');
          return;
        }

        var html = `
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>${title || 'Imprimir menú'}</title>
  <style>
    body{ font-family: Arial, sans-serif; padding: 24px; color:#111; }
    h1{ font-size: 20px; margin:0 0 14px 0; }
    table{ width:100%; border-collapse: collapse; }
    table, th, td{ border:1px solid #ddd; }
    th, td{ padding:8px; text-align:left; vertical-align:top; }
  </style>
</head>
<body>
  <h1>${title || 'Menú del proveedor'}</h1>
  ${el.outerHTML}
  <script>
    window.onload = function(){ window.print(); window.close(); };
  <\/script>
</body>
</html>
        `;

        w.document.open();
        w.document.write(html);
        w.document.close();
      }

      async function shareText(title, text, url){
        // Web Share (móviles)
        if (navigator.share){
          try{
            await navigator.share({ title: title, text: text, url: url });
            return;
          }catch(e){
            // si cancelan, no pasa nada
          }
        }

        // Portapapeles
        var toCopy = [title, text, url].filter(Boolean).join('\n\n');
        try{
          await navigator.clipboard.writeText(toCopy);
          alert('Menú copiado al portapapeles ✅');
        }catch(e){
          window.prompt('Copia el menú:', toCopy);
        }
      }

      function insertButtonsAfter(menuEl){
        if (!menuEl) return;

        // Evitar duplicados
        if (document.getElementById('cscrm-sharebar')) return;

        var bar = document.createElement('div');
        bar.className = 'cscrm-sharebar';
        bar.id = 'cscrm-sharebar';

        bar.innerHTML = `
          <button type="button" class="button button-primary" id="cscrm-btn-print">🖨️ Imprimir menú</button>
          <button type="button" class="button" id="cscrm-btn-share">📤 Compartir menú</button>
          <button type="button" class="button" id="cscrm-btn-wa">💬 WhatsApp</button>
          <span class="cscrm-hint">Se muestra solo cuando hay menú asignado</span>
        `;

        // Insertar barra debajo del menú
        menuEl.parentNode.insertBefore(bar, menuEl.nextSibling);

        var title = 'Menú del proveedor (Catering Safor)';
        var url = window.location.href;

        document.getElementById('cscrm-btn-print').addEventListener('click', function(){
          var menu = findMenuBlock();
          printBlock(menu, title);
        });

        document.getElementById('cscrm-btn-share').addEventListener('click', function(){
          var menu = findMenuBlock();
          var text = getMenuText(menu);
          shareText(title, text, url);
        });

        document.getElementById('cscrm-btn-wa').addEventListener('click', function(){
          var menu = findMenuBlock();
          var text = getMenuText(menu);
          var msg = [title, text, url].filter(Boolean).join('\n\n');
          var wa = 'https://wa.me/?text=' + encodeURIComponent(msg);
          window.open(wa, '_blank');
        });
      }

      // Esperamos a que cargue el admin
      document.addEventListener('DOMContentLoaded', function(){
        var menu = findMenuBlock();
        if (!menu) return; // si aún no hay menú asignado/mostrado, no ponemos botones
        insertButtonsAfter(menu);
      });

      // Extra: por si tu página actualiza el contenido tras guardar sin recargar (AJAX)
      // Reintenta unas veces durante 4 segundos.
      var tries = 0;
      var timer = setInterval(function(){
        if (document.getElementById('cscrm-sharebar')) { clearInterval(timer); return; }
        var menu = findMenuBlock();
        if (menu){
          insertButtonsAfter(menu);
          clearInterval(timer);
        }
        tries++;
        if (tries >= 20) clearInterval(timer);
      }, 200);

    })();
    </script>
    <?php
}
