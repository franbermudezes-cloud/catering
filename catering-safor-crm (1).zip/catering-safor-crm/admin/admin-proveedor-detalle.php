<?php
if (!defined('ABSPATH')) exit;

function cscrm_admin_proveedor_detalle() {
    global $wpdb;

    $tabla_prov  = $wpdb->prefix . 'catering_proveedores';
    $tabla_menus = $wpdb->prefix . 'catering_menus';

    if (!isset($_GET['id'])) {
        echo '<div class="wrap"><p>Proveedor no especificado.</p></div>';
        return;
    }

    $proveedor_id = intval($_GET['id']);

    /* =========================
       GUARDAR CAMBIOS
    ========================== */
    if (isset($_POST['cscrm_update_proveedor'])) {

        $wpdb->update(
            $tabla_prov,
            [
                'nombre'          => sanitize_text_field($_POST['nombre']),
                'telefono'        => sanitize_text_field($_POST['telefono']),
                'email'           => sanitize_email($_POST['email']),
                'contacto'        => sanitize_text_field($_POST['contacto']),
                'direccion'       => sanitize_text_field($_POST['direccion']),
                'cp'              => sanitize_text_field($_POST['cp']),
                'ciudad'          => sanitize_text_field($_POST['ciudad']),
                'provincia'       => sanitize_text_field($_POST['provincia']),
                'razon_social'    => sanitize_text_field($_POST['razon_social']),
                'cif'             => sanitize_text_field($_POST['cif']),
                'tipo_proveedor'  => sanitize_text_field($_POST['tipo_proveedor']),
                'servicios_extra' => sanitize_textarea_field($_POST['servicios_extra']),
                'observaciones'   => sanitize_textarea_field($_POST['observaciones']),
            ],
            ['id' => $proveedor_id]
        );

        echo '<div class="updated notice"><p>Proveedor actualizado correctamente.</p></div>';
    }

    /* =========================
       CARGAR DATOS
    ========================== */
    $proveedor = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM $tabla_prov WHERE id = %d",
            $proveedor_id
        )
    );

    if (!$proveedor) {
        echo '<div class="wrap"><p>Proveedor no encontrado.</p></div>';
        return;
    }

    $menus = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM $tabla_menus WHERE proveedor_id = %d ORDER BY precio_menu ASC",
            $proveedor_id
        )
    );
    ?>

    <div class="wrap">
        <h1>Proveedor: <?= esc_html($proveedor->nombre) ?></h1>

        <!-- =========================
             DATOS DEL PROVEEDOR
        ========================== -->
        <form method="post" style="max-width:900px; background:#fff; padding:20px; border:1px solid #ccd0d4;">
            <h2>Datos generales</h2>

            <p>
                <label>Nombre comercial</label><br>
                <input type="text" name="nombre" value="<?= esc_attr($proveedor->nombre) ?>" style="width:100%;">
            </p>

            <p>
                <label>Persona de contacto</label><br>
                <input type="text" name="contacto" value="<?= esc_attr($proveedor->contacto) ?>" style="width:100%;">
            </p>

            <p style="display:flex; gap:10px;">
                <span style="flex:1;">
                    <label>Teléfono</label><br>
                    <input type="text" name="telefono" value="<?= esc_attr($proveedor->telefono) ?>">
                </span>
                <span style="flex:1;">
                    <label>Email</label><br>
                    <input type="email" name="email" value="<?= esc_attr($proveedor->email) ?>">
                </span>
            </p>

            <hr>

            <h2>Dirección</h2>

            <p>
                <label>Dirección</label><br>
                <input type="text" name="direccion" value="<?= esc_attr($proveedor->direccion) ?>" style="width:100%;">
            </p>

            <p style="display:flex; gap:10px;">
                <span style="flex:1;">
                    <label>Código Postal</label><br>
                    <input type="text" name="cp" value="<?= esc_attr($proveedor->cp) ?>">
                </span>
                <span style="flex:1;">
                    <label>Ciudad</label><br>
                    <input type="text" name="ciudad" value="<?= esc_attr($proveedor->ciudad) ?>">
                </span>
                <span style="flex:1;">
                    <label>Provincia</label><br>
                    <input type="text" name="provincia" value="<?= esc_attr($proveedor->provincia) ?>">
                </span>
            </p>

            <hr>

            <h2>Datos fiscales</h2>

            <p>
                <label>Razón social</label><br>
                <input type="text" name="razon_social" value="<?= esc_attr($proveedor->razon_social) ?>" style="width:100%;">
            </p>

            <p style="display:flex; gap:10px;">
                <span style="flex:1;">
                    <label>CIF / NIF</label><br>
                    <input type="text" name="cif" value="<?= esc_attr($proveedor->cif) ?>">
                </span>
                <span style="flex:1;">
                    <label>Tipo proveedor</label><br>
                    <select name="tipo_proveedor">
                        <option value="">— Seleccionar —</option>
                        <option value="empresa" <?= $proveedor->tipo_proveedor === 'empresa' ? 'selected' : '' ?>>Empresa</option>
                        <option value="autonomo" <?= $proveedor->tipo_proveedor === 'autonomo' ? 'selected' : '' ?>>Autónomo</option>
                    </select>
                </span>
            </p>

            <hr>

            <h2>Servicios y observaciones</h2>

            <p>
                <label>Servicios adicionales</label><br>
                <textarea name="servicios_extra" rows="3" style="width:100%;"><?= esc_textarea($proveedor->servicios_extra) ?></textarea>
            </p>

            <p>
                <label>Observaciones internas</label><br>
                <textarea name="observaciones" rows="3" style="width:100%;"><?= esc_textarea($proveedor->observaciones) ?></textarea>
            </p>

            <button type="submit"
                    name="cscrm_update_proveedor"
                    class="button button-primary">
                Guardar cambios
            </button>
        </form>

        <!-- =========================
             MENÚS ASOCIADOS
        ========================== -->
        <h2 style="margin-top:40px;">Menús asociados</h2>

        <?php if (!$menus): ?>
            <p>Este proveedor no tiene menús asociados.</p>
        <?php else: ?>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Menú</th>
                        <th>Precio</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($menus as $m): ?>
                        <tr>
                            <td><?= esc_html($m->nombre_menu) ?></td>
                            <td><?= esc_html($m->precio_menu) ?> €</td>
                            <td><?= $m->disponible ? 'Activo' : 'Inactivo' ?></td>
                            <td>
                                <a href="<?= admin_url('admin.php?page=cscrm_menus&editar=' . $m->id) ?>"
                                   class="button">
                                    Editar menú
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <p style="margin-top:20px;">
            <a href="<?= admin_url('admin.php?page=cscrm_proveedores') ?>" class="button">
                ← Volver a proveedores
            </a>
        </p>
    </div>
<?php
}
