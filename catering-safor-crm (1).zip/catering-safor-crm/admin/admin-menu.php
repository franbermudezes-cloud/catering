<?php
if (!defined('ABSPATH')) exit;

/* ======================================================
   CARGAR LIBRERÍAS
====================================================== */
add_action('admin_enqueue_scripts', 'cscrm_cargar_librerias');
function cscrm_cargar_librerias() {

    // Chart.js
    wp_enqueue_script(
        'chartjs',
        'https://cdn.jsdelivr.net/npm/chart.js',
        [],
        null,
        true
    );

    // FullCalendar
    wp_enqueue_style(
        'fullcalendar-css',
        'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css'
    );

    wp_enqueue_script(
        'fullcalendar-js',
        'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js',
        [],
        null,
        true
    );
}

/* ======================================================
   MENÚ ADMIN
====================================================== */
add_action('admin_menu', 'cscrm_register_admin_menu');
function cscrm_register_admin_menu() {

    add_menu_page(
        'Catering Safor CRM',
        'Catering Safor',
        'manage_options',
        'cscrm_dashboard',
        'cscrm_dashboard_page',
        'dashicons-food',
        26
    );

    add_submenu_page(
        'cscrm_dashboard',
        'Panel',
        'Panel',
        'manage_options',
        'cscrm_dashboard',
        'cscrm_dashboard_page'
    );

    add_submenu_page(
        'cscrm_dashboard',
        'Gestión',
        'Gestión',
        'manage_options',
        'cscrm_catering_safor',
        'cscrm_admin_catering_safor'
    );

    add_submenu_page(
        'cscrm_dashboard',
        'Agenda',
        'Agenda',
        'manage_options',
        'cscrm_agenda',
        'cscrm_agenda_page'
    );


    add_submenu_page(
        'cscrm_dashboard',
        'Proveedores',
        'Proveedores',
        'manage_options',
        'cscrm_proveedores',
        'cscrm_admin_proveedores'
    );

    add_submenu_page(
        'cscrm_dashboard',
        'Menús',
        'Menús',
        'manage_options',
        'cscrm_menus',
        'cscrm_admin_menus'
    );

    add_submenu_page(
        'cscrm_dashboard',
        'Solicitudes',
        'Solicitudes',
        'manage_options',
        'cscrm_solicitudes',
        'cscrm_admin_solicitudes'
    );
}

/* ======================================================
   PANEL (KPIs + RESUMEN + 3 GRÁFICAS EN LÍNEA)
   Basado en estado_propuesta + evento_datetime
====================================================== */
function cscrm_dashboard_page() {
    global $wpdb;

    $t_solicitudes = $wpdb->prefix . 'catering_solicitudes';
    $t_menus       = $wpdb->prefix . 'catering_menus';
    $t_prov        = $wpdb->prefix . 'catering_proveedores';

    // Detectar columnas
    $cols_sol = $wpdb->get_col("DESC $t_solicitudes", 0);
    $tiene_estado_prop = is_array($cols_sol) && in_array('estado_propuesta', $cols_sol, true);
    $tiene_evento_dt   = is_array($cols_sol) && in_array('evento_datetime', $cols_sol, true);

    // KPIs base
    $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t_solicitudes");
    $total_proveedores = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t_prov");
    $total_menus = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t_menus");

    // Precios (según tu sistema)
    $precio_expr = "CAST(NULLIF(menu_elegido,'') AS DECIMAL(10,2))";
    $precio_expr_bk = "CAST(NULLIF(precio_menu,'') AS DECIMAL(10,2))";
    $precio_final = "COALESCE($precio_expr, $precio_expr_bk)";

    // Conteos propuesta
    $aceptadas_prop = 0;
    $rechazadas_prop = 0;
    $sin_decidir_prop = 0;

    if ($tiene_estado_prop) {
        $aceptadas_prop = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t_solicitudes WHERE estado_propuesta=%s", 'Aceptada'));
        $rechazadas_prop = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t_solicitudes WHERE estado_propuesta=%s", 'Rechazada'));
        $sin_decidir_prop = (int)$wpdb->get_var("
            SELECT COUNT(*) FROM $t_solicitudes
            WHERE estado_propuesta IS NULL OR estado_propuesta=''
        ");
    }

    // Próximos eventos (aceptados por propuesta)
    $proximos = [];
    if ($tiene_estado_prop && $tiene_evento_dt) {
        $proximos = $wpdb->get_results($wpdb->prepare("
            SELECT id, cliente, lugar_evento, evento_datetime, proveedor_id, ($precio_final) AS precio
            FROM $t_solicitudes
            WHERE estado_propuesta=%s
              AND evento_datetime IS NOT NULL
              AND evento_datetime <> ''
            ORDER BY evento_datetime ASC
            LIMIT 5
        ", 'Aceptada'));
    }

    // Nombre proveedor para el listado de próximos
    if ($proximos) {
        foreach ($proximos as $e) {
            $e->proveedor_nombre = '';
            if (!empty($e->proveedor_id)) {
                $e->proveedor_nombre = (string)$wpdb->get_var(
                    $wpdb->prepare("SELECT nombre FROM $t_prov WHERE id=%d", (int)$e->proveedor_id)
                );
            }
        }
    }

    // Proveedores TOP/LOW (solo aceptadas) usando proveedor_id (FIABLE y sin duplicar)
    $prov_labels = [];
    $prov_values = [];

    if ($tiene_estado_prop) {

        $proveedores_counts = $wpdb->get_results($wpdb->prepare("
            SELECT
                p.nombre AS proveedor,
                COUNT(*) AS total
            FROM $t_solicitudes s
            INNER JOIN $t_prov p ON p.id = s.proveedor_id
            WHERE s.estado_propuesta = %s
              AND s.proveedor_id IS NOT NULL
              AND s.proveedor_id <> 0
            GROUP BY s.proveedor_id
            ORDER BY total DESC
        ", 'Aceptada'));

        if ($proveedores_counts && count($proveedores_counts) > 0) {

            $top = [];
            $bottom = [];

            $total_prov = count($proveedores_counts);

            if ($total_prov <= 1) {
                $top = $proveedores_counts;
            } elseif ($total_prov == 2) {
                $top = [$proveedores_counts[0]];
                $bottom = [$proveedores_counts[1]];
            } else {
                $half = (int)ceil($total_prov / 2);
                $top = array_slice($proveedores_counts, 0, $half);
                $bottom = array_slice($proveedores_counts, $half);
            }

            foreach ($top as $r) {
                $prov_labels[] = 'TOP: ' . $r->proveedor;
                $prov_values[] = (int)$r->total;
            }
            foreach ($bottom as $r) {
                $prov_labels[] = 'LOW: ' . $r->proveedor;
                $prov_values[] = (int)$r->total;
            }
        }
    }

    // Precios más solicitados (solo aceptadas)
    $precio_labels = [];
    $precio_values = [];

    if ($tiene_estado_prop) {
        $precios_counts = $wpdb->get_results($wpdb->prepare("
            SELECT ($precio_final) AS precio, COUNT(*) AS total
            FROM $t_solicitudes
            WHERE estado_propuesta=%s
              AND ($precio_final) IS NOT NULL
            GROUP BY precio
            ORDER BY total DESC
            LIMIT 10
        ", 'Aceptada'));

        if ($precios_counts) {
            foreach ($precios_counts as $r) {
                $precio_labels[] = number_format((float)$r->precio, 2, ',', '.') . ' €';
                $precio_values[] = (int)$r->total;
            }
        }
    }

    ?>
    <div class="wrap cscrm-wrap">

        <style>
            .cscrm-card-ui{
                border:1px solid rgba(0,0,0,.08);
                border-radius:14px;
                background:#fff;
                box-shadow: 0 6px 18px rgba(0,0,0,.06);
                transition: transform .12s ease, box-shadow .12s ease, border-color .12s ease;
            }
            .cscrm-card-ui:hover{ transform: translateY(-1px); box-shadow: 0 10px 26px rgba(0,0,0,.10); border-color: rgba(0,0,0,.14); }

            .cscrm-kpi-grid{ display:grid; grid-template-columns:repeat(4, minmax(220px, 1fr)); gap:18px; margin-top:10px; }
            @media (max-width: 1200px){ .cscrm-kpi-grid{ grid-template-columns:repeat(2, minmax(220px, 1fr)); } }
            @media (max-width: 620px){ .cscrm-kpi-grid{ grid-template-columns:1fr; } }

            .cscrm-kpi-card{ display:flex; align-items:center; justify-content:space-between; gap:14px; padding:18px; text-decoration:none !important; min-height:94px; }
            .cscrm-kpi-left{ display:flex; flex-direction:column; gap:6px; min-width:0; }
            .cscrm-kpi-label{ font-size:12.5px; letter-spacing:.35px; color:#59636e; text-transform:uppercase; font-weight:700; }
            .cscrm-kpi-value{ font-size:36px; font-weight:850; color:#101828; margin:0; line-height:1; }
            .cscrm-kpi-sub{ font-size:13px; color:#667085; margin:0; display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
            .cscrm-pill{ display:inline-flex; align-items:center; gap:6px; padding:3px 9px; border-radius:999px; border:1px solid rgba(0,0,0,.08); background: rgba(34,113,177,.06); color:#1f5f95; font-size:12px; font-weight:700; }

            .cscrm-kpi-icon{ width:46px; height:46px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:18px; border:1px solid rgba(0,0,0,.08); background: linear-gradient(180deg, rgba(34,113,177,.10), rgba(34,113,177,.03)); color:#2271b1; }
            .cscrm-kpi-icon.is-green{ background: linear-gradient(180deg, rgba(2,122,72,.12), rgba(2,122,72,.03)); color:#027A48; }
            .cscrm-kpi-icon.is-purple{ background: linear-gradient(180deg, rgba(124,58,237,.14), rgba(124,58,237,.04)); color:#6D28D9; }
            .cscrm-kpi-icon.is-amber{ background: linear-gradient(180deg, rgba(245,158,11,.14), rgba(245,158,11,.04)); color:#B45309; }

            .cscrm-title-row{ margin-top:24px; display:flex; align-items:baseline; justify-content:space-between; gap:12px; }
            .cscrm-title-row h2{ margin:0; font-size:16px; font-weight:800; color:#101828; }
            .cscrm-title-row .cscrm-title-meta{ font-size:12.5px; color:#667085; }

            .cscrm-table-wrap{ padding:12px; margin-top:10px; }
            .cscrm-table-wrap table.widefat{ border:none !important; box-shadow:none !important; }

            .cscrm-charts-grid{ display:grid; grid-template-columns:repeat(3, minmax(260px, 1fr)); gap:18px; align-items:stretch; margin-top:12px; }
            @media (max-width: 1100px){ .cscrm-charts-grid{ grid-template-columns:1fr; } }
            .cscrm-chart-card{ padding:16px 16px 10px; }
            .cscrm-chart-head{ display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:8px; }
            .cscrm-chart-head h3{ margin:0; font-size:14px; font-weight:800; color:#101828; }
            .cscrm-mini{ font-size:12px; color:#667085; margin:0; }
        </style>

        <!-- 4 tarjetas -->
        <div class="cscrm-kpi-grid">
            <a href="admin.php?page=cscrm_solicitudes" class="cscrm-kpi-card cscrm-card-ui">
                <div class="cscrm-kpi-left">
                    <div class="cscrm-kpi-label">Solicitudes</div>
                    <div class="cscrm-kpi-value"><?php echo (int)$total; ?></div>
                    <div class="cscrm-kpi-sub">Ver listado</div>
                </div>
                <div class="cscrm-kpi-icon">🧾</div>
            </a>

            <a href="admin.php?page=cscrm_proveedores" class="cscrm-kpi-card cscrm-card-ui">
                <div class="cscrm-kpi-left">
                    <div class="cscrm-kpi-label">Proveedores</div>
                    <div class="cscrm-kpi-value"><?php echo (int)$total_proveedores; ?></div>
                    <div class="cscrm-kpi-sub">Gestionar</div>
                </div>
                <div class="cscrm-kpi-icon is-green">👥</div>
            </a>

            <a href="admin.php?page=cscrm_menus" class="cscrm-kpi-card cscrm-card-ui">
                <div class="cscrm-kpi-left">
                    <div class="cscrm-kpi-label">Menús</div>
                    <div class="cscrm-kpi-value"><?php echo (int)$total_menus; ?></div>
                    <div class="cscrm-kpi-sub">Editar</div>
                </div>
                <div class="cscrm-kpi-icon is-purple">🍽️</div>
            </a>

            <a href="admin.php?page=cscrm_agenda" class="cscrm-kpi-card cscrm-card-ui">
                <div class="cscrm-kpi-left">
                    <div class="cscrm-kpi-label">Propuestas</div>
                    <div class="cscrm-kpi-value">✅</div>
                    <div class="cscrm-kpi-sub">
                        <?php if ($tiene_estado_prop): ?>
                            <span class="cscrm-pill">Aceptadas: <?php echo (int)$aceptadas_prop; ?></span>
                            <span>Rechazadas: <?php echo (int)$rechazadas_prop; ?></span>
                        <?php else: ?>
                            <span class="cscrm-pill">Falta estado_propuesta</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="cscrm-kpi-icon is-amber">📅</div>
            </a>
        </div>

        <!-- Próximos -->
        <div class="cscrm-title-row">
            <h2>Próximos eventos</h2>
            <div class="cscrm-title-meta"></div>
        </div>

        <div class="cscrm-card-ui cscrm-table-wrap">
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Cliente</th>
                        <th>Lugar</th>
                        <th>Propuesta</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$tiene_estado_prop || !$tiene_evento_dt): ?>
                        <tr><td colspan="5">No disponible.</td></tr>
                    <?php elseif ($proximos): foreach ($proximos as $e): ?>
                        <tr>
                            <td><?php echo esc_html(date('d/m/Y H:i', strtotime($e->evento_datetime))); ?></td>
                            <td><?php echo esc_html($e->cliente); ?></td>
                            <td><?php echo esc_html($e->lugar_evento); ?></td>
                            <td>
                                <?php
                                    $prov = !empty($e->proveedor_nombre) ? $e->proveedor_nombre : 'Proveedor';
                                    $prc = ($e->precio !== null && $e->precio !== '') ? number_format((float)$e->precio, 2, ',', '.') . ' €' : '—';
                                    echo esc_html($prov . ' · ' . $prc);
                                ?>
                            </td>
                            <td>
                                <a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=cscrm_catering_safor&open=' . (int)$e->id)); ?>">
                                    Ver
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="5">No hay eventos próximos.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- 3 gráficas -->
        <div class="cscrm-title-row">
            <h2>Estadísticas</h2>
            <div class="cscrm-title-meta"></div>
        </div>

        <div class="cscrm-charts-grid">
            <div class="cscrm-chart-card cscrm-card-ui">
                <div class="cscrm-chart-head">
                    <h3>Estado</h3>
                    <p class="cscrm-mini">Propuestas</p>
                </div>
                <canvas id="graficaEstados" style="max-height:220px;"></canvas>
            </div>

            <div class="cscrm-chart-card cscrm-card-ui">
                <div class="cscrm-chart-head">
                    <h3>Proveedores</h3>
                    <p class="cscrm-mini">Aceptadas</p>
                </div>
                <canvas id="graficaProveedores" style="max-height:220px;"></canvas>
                <?php if (empty($prov_labels)) : ?>
                    <p style="margin:10px 0 0;"><em>No hay datos.</em></p>
                <?php endif; ?>
            </div>

            <div class="cscrm-chart-card cscrm-card-ui">
                <div class="cscrm-chart-head">
                    <h3>Precios</h3>
                    <p class="cscrm-mini">Aceptadas</p>
                </div>
                <canvas id="graficaPrecios" style="max-height:220px;"></canvas>
                <?php if (empty($precio_labels)) : ?>
                    <p style="margin:10px 0 0;"><em>No hay datos.</em></p>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {

        // Estado (colores)
        new Chart(document.getElementById('graficaEstados'), {
            type: 'doughnut',
            data: {
                labels: ['Aceptadas','Rechazadas','Sin decidir'],
                datasets: [{
                    data: [<?php echo (int)$aceptadas_prop; ?>, <?php echo (int)$rechazadas_prop; ?>, <?php echo (int)$sin_decidir_prop; ?>],
                    backgroundColor: [
                        '#22c55e', // Aceptadas
                        '#ef4444', // Rechazadas
                        '#f59e0b'  // Sin decidir
                    ]
                }]
            },
            options: { plugins: { legend: { position: 'top' } } }
        });

        // Proveedores (color índigo)
        <?php if (!empty($prov_labels)) : ?>
        new Chart(document.getElementById('graficaProveedores'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($prov_labels); ?>,
                datasets: [{
                    label: 'Aceptadas',
                    data: <?php echo json_encode($prov_values); ?>,
                    backgroundColor: '#6366f1'
                }]
            },
            options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
        });
        <?php endif; ?>

        // Precios (color violeta)
        <?php if (!empty($precio_labels)) : ?>
        new Chart(document.getElementById('graficaPrecios'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($precio_labels); ?>,
                datasets: [{
                    label: 'Aceptadas',
                    data: <?php echo json_encode($precio_values); ?>,
                    backgroundColor: '#8b5cf6'
                }]
            },
            options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
        });
        <?php endif; ?>

    });
    </script>

    <?php
}

/* ======================================================
   AGENDA COMPLETA
   SOLO aceptadas de propuesta + evento_datetime
====================================================== */
function cscrm_agenda_page() {
    global $wpdb;

    $t_solicitudes = $wpdb->prefix . 'catering_solicitudes';
    $t_prov        = $wpdb->prefix . 'catering_proveedores';

    $cols_sol = $wpdb->get_col("DESC $t_solicitudes", 0);
    $tiene_estado_prop = is_array($cols_sol) && in_array('estado_propuesta', $cols_sol, true);
    $tiene_evento_dt   = is_array($cols_sol) && in_array('evento_datetime', $cols_sol, true);

    if (!$tiene_estado_prop || !$tiene_evento_dt) {
        echo '<div class="wrap"><h1>Agenda</h1><p>No disponible.</p></div>';
        return;
    }

    $precio_expr = "CAST(NULLIF(menu_elegido,'') AS DECIMAL(10,2))";
    $precio_expr_bk = "CAST(NULLIF(precio_menu,'') AS DECIMAL(10,2))";
    $precio_final = "COALESCE($precio_expr, $precio_expr_bk)";

    $eventos = $wpdb->get_results($wpdb->prepare("
        SELECT id, cliente, lugar_evento, evento_datetime, proveedor_id, ($precio_final) AS precio
        FROM $t_solicitudes
        WHERE estado_propuesta=%s
          AND evento_datetime IS NOT NULL
          AND evento_datetime <> ''
    ", 'Aceptada'));

    $eventos_js = [];
    foreach ($eventos as $e) {

        $ts = strtotime((string)$e->evento_datetime);
        if (!$ts) continue;

        $iso = date('Y-m-d\TH:i:s', $ts);

        $prov = '';
        if (!empty($e->proveedor_id)) {
            $prov = (string)$wpdb->get_var($wpdb->prepare("SELECT nombre FROM $t_prov WHERE id=%d", (int)$e->proveedor_id));
        }
        $prov = $prov ? $prov : 'Proveedor';

        $prc = ($e->precio !== null && $e->precio !== '') ? number_format((float)$e->precio, 2, ',', '.') . ' €' : '';

        $title = trim($e->cliente . ' · ' . $e->lugar_evento);
        if ($prov || $prc) $title .= ' | ' . trim($prov . ' ' . $prc);

        $eventos_js[] = [
            'title' => $title,
            'start' => $iso,
            'url'   => admin_url('admin.php?page=cscrm_catering_safor&open=' . (int)$e->id)
        ];
    }
    ?>

    <div class="wrap">
        <h1>Agenda</h1>

        <div id="calendario" style="margin-top:10px;background:#fff;padding:20px;border-radius:14px;border:1px solid rgba(0,0,0,.08);box-shadow:0 6px 18px rgba(0,0,0,.06);"></div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {

        let calendar = new FullCalendar.Calendar(
            document.getElementById('calendario'),
            {
                initialView: 'dayGridMonth',
                locale: 'es',
                height: 'auto',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                events: <?php echo json_encode($eventos_js); ?>,
                eventClick: function(info){
                    if (info.event.url) {
                        window.location.href = info.event.url;
                        info.jsEvent.preventDefault();
                    }
                }
            }
        );

        calendar.render();
    });
    </script>


    <?php
	
}