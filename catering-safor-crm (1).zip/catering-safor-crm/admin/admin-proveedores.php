<?php
if (!defined('ABSPATH')) exit;

function cscrm_admin_proveedores() {
    global $wpdb;

    $tabla_prov  = $wpdb->prefix . 'catering_proveedores';
    $tabla_menus = $wpdb->prefix . 'catering_menus';

    /* =========================
       ELIMINAR PROVEEDOR
    ========================== */
    if (isset($_GET['eliminar'])) {
        $id = intval($_GET['eliminar']);

        // Eliminamos primero sus menús
        $wpdb->delete($tabla_menus, ['proveedor_id' => $id]);

        // Eliminamos proveedor
        $wpdb->delete($tabla_prov, ['id' => $id]);

        echo '<div class="updated notice"><p>Proveedor eliminado correctamente.</p></div>';
    }

    /* =========================
       CREAR PROVEEDOR
    ========================== */
    if (isset($_POST['cscrm_add_proveedor'])) {

        $wpdb->insert($tabla_prov, [
            'nombre'          => sanitize_text_field($_POST['nombre']),
            'telefono'        => sanitize_text_field($_POST['telefono']),
            'email'           => sanitize_email($_POST['email']),
            'contacto'        => sanitize_text_field($_POST['contacto']),
            'direccion'       => sanitize_text_field($_POST['direccion']),
            'cp'              => sanitize_text_field($_POST['cp']),
            'ciudad'          => sanitize_text_field($_POST['ciudad']),
            'provincia'       => sanitize_text_field($_POST['provincia']),
            'comarca'         => sanitize_text_field($_POST['comarca']),
            'razon_social'    => sanitize_text_field($_POST['razon_social']),
            'cif'             => sanitize_text_field($_POST['cif']),
            'tipo_proveedor'  => sanitize_text_field($_POST['tipo_proveedor']),
            'servicios_extra' => sanitize_textarea_field($_POST['servicios_extra']),
            'observaciones'   => sanitize_textarea_field($_POST['observaciones']),
        ]);

        echo '<div class="updated notice"><p>Proveedor creado correctamente.</p></div>';
    }

    /* =========================
       LISTADO
    ========================== */
    $proveedores = $wpdb->get_results("
        SELECT *
        FROM $tabla_prov
        ORDER BY nombre ASC
    ");
    ?>

    <div class="wrap">
        <h1>Proveedores</h1>

        <!-- BOTÓN CREAR -->
        <button class="button button-primary button-hero"
                onclick="document.getElementById('form-proveedor').style.display =
                document.getElementById('form-proveedor').style.display === 'none' ? 'block' : 'none';">
            ➕ Añadir proveedor
        </button>

        <!-- FORMULARIO -->
        <div id="form-proveedor"
             style="display:none; margin-top:20px; max-width:900px; background:#fff; padding:20px; border:1px solid #ccd0d4;">
            <form method="post">

                <h2>Datos generales</h2>
                <p><input type="text" name="nombre" placeholder="Nombre comercial *" required style="width:100%;"></p>
                <p><input type="text" name="contacto" placeholder="Persona de contacto" style="width:100%;"></p>

                <p style="display:flex; gap:10px;">
                    <input type="text" name="telefono" placeholder="Teléfono" style="flex:1;">
                    <input type="email" name="email" placeholder="Email" style="flex:1;">
                </p>

                <h2>Dirección</h2>
                <p><input type="text" name="direccion" placeholder="Dirección" style="width:100%;"></p>

                <p style="display:flex; gap:10px;">
                    <input type="text" name="cp" placeholder="CP" style="flex:1;">
                    <input type="text" name="ciudad" placeholder="Ciudad" style="flex:1;">
                    <input type="text" name="provincia" placeholder="Provincia" style="flex:1;">
                </p>

                <p>
                    <input type="text" name="comarca"
                           placeholder="Comarca / zona de servicio"
                           style="width:100%;">
                </p>

                <h2>Datos fiscales</h2>
                <p><input type="text" name="razon_social" placeholder="Razón social" style="width:100%;"></p>

                <p style="display:flex; gap:10px;">
                    <input type="text" name="cif" placeholder="CIF / NIF" style="flex:1;">
                    <select name="tipo_proveedor" style="flex:1;">
                        <option value="">Tipo proveedor</option>
                        <option value="empresa">Empresa</option>
                        <option value="autonomo">Autónomo</option>
                    </select>
                </p>

                <h2>Observaciones</h2>
                <textarea name="servicios_extra" placeholder="Servicios adicionales" style="width:100%;"></textarea>
                <textarea name="observaciones" placeholder="Observaciones internas" style="width:100%;"></textarea>

                <br>
                <button type="submit" name="cscrm_add_proveedor" class="button button-primary">
                    Guardar proveedor
                </button>
            </form>
        </div>

        <hr>

        <!-- TABLA -->
        <h2>Listado de proveedores</h2>

        <table class="widefat striped">
            <thead>
                <tr>
                    <th>Proveedor</th>
                    <th>Contacto</th>
                    <th>Teléfono</th>
                    <th>Email</th>
                    <th>Ciudad</th>
                    <th>Comarca</th>
                    <th>Menús</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$proveedores): ?>
                    <tr><td colspan="8">No hay proveedores.</td></tr>
                <?php endif; ?>

                <?php foreach ($proveedores as $p): ?>

                    <?php
                    $menus = $wpdb->get_results(
                        $wpdb->prepare(
                            "SELECT nombre_menu, precio_menu
                             FROM $tabla_menus
                             WHERE proveedor_id = %d
                             ORDER BY precio_menu ASC",
                            $p->id
                        )
                    );
                    ?>

                    <tr>
                        <td><?= esc_html($p->nombre) ?></td>
                        <td><?= esc_html($p->contacto) ?></td>
                        <td><?= esc_html($p->telefono) ?></td>
                        <td><?= esc_html($p->email) ?></td>
                        <td><?= esc_html($p->ciudad) ?></td>
                        <td><?= esc_html($p->comarca) ?></td>

                        <td>
                            <?php if ($menus): ?>
                                <?php foreach ($menus as $m): ?>
                                    <div>
                                        <?= esc_html($m->nombre_menu) ?> –
                                        <strong><?= esc_html($m->precio_menu) ?> €</strong>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <em>Sin menús</em>
                            <?php endif; ?>
                        </td>

                        <td>
                            <a href="<?= admin_url('admin.php?page=cscrm_proveedor&id=' . $p->id) ?>"
                               class="button">
                                Ver proveedor
                            </a>

                            <a href="<?= admin_url('admin.php?page=cscrm_proveedores&eliminar=' . $p->id) ?>"
                               class="button button-secondary"
                               onclick="return confirm('¿Eliminar este proveedor y sus menús?');">
                                Eliminar
                            </a>
                        </td>
                    </tr>

                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php
}
