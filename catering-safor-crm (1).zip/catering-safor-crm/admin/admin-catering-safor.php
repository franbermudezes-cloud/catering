<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('cscrm_admin_catering_safor')) {
function cscrm_admin_catering_safor() {
    global $wpdb;

    $tabla_sol = $wpdb->prefix . 'catering_solicitudes';
    $tabla_men = $wpdb->prefix . 'catering_menus';
    $tabla_pro = $wpdb->prefix . 'catering_proveedores';

    $cscrm_logo_url = 'https://appneuralai.es/wp-content/uploads/2026/01/Catering-Safor.jpg';
    $cscrm_fecha_propuesta = date_i18n('d/m/Y');

    // Columnas existentes
    $cols_sol = $wpdb->get_col("DESC $tabla_sol", 0);
    $tiene_precio_menu     = is_array($cols_sol) && in_array('precio_menu', $cols_sol, true);
    $tiene_menu_elegido    = is_array($cols_sol) && in_array('menu_elegido', $cols_sol, true);
    $tiene_created_at      = is_array($cols_sol) && in_array('created_at', $cols_sol, true);
    $tiene_evento_datetime = is_array($cols_sol) && in_array('evento_datetime', $cols_sol, true);
    $tiene_comentario_doc  = is_array($cols_sol) && in_array('comentario_doc', $cols_sol, true);

    $tiene_estado_prop     = is_array($cols_sol) && in_array('estado_propuesta', $cols_sol, true);
    $tiene_fecha_estado    = is_array($cols_sol) && in_array('fecha_estado_propuesta', $cols_sol, true);

    $cols_men = $wpdb->get_col("DESC $tabla_men", 0);
    $tiene_menu_id = is_array($cols_men) && in_array('id', $cols_men, true);

    $fmt_dt = function($mysql_dt) {
        if (empty($mysql_dt)) return '';
        $ts = strtotime($mysql_dt);
        if (!$ts) return '';
        return date_i18n('d/m/Y H:i', $ts);
    };

    // =========================
    // CAMBIAR ESTADO PROPUESTA
    // =========================
    if (isset($_POST['cambiar_estado_propuesta'])) {
        $solicitud_id = isset($_POST['solicitud_id']) ? intval($_POST['solicitud_id']) : 0;
        $nuevo_estado = isset($_POST['nuevo_estado']) ? sanitize_text_field($_POST['nuevo_estado']) : '';

        if ($solicitud_id > 0 && in_array($nuevo_estado, array('Aceptada','Rechazada'), true) && $tiene_estado_prop) {
            $prov = $wpdb->get_var($wpdb->prepare("SELECT proveedor_id FROM $tabla_sol WHERE id=%d", $solicitud_id));
            if (empty($prov)) {
                echo '<div class="error notice"><p>Para aceptar/rechazar primero asigna un menú/proveedor.</p></div>';
            } else {
                $upd = array('estado_propuesta' => $nuevo_estado);
                if ($tiene_fecha_estado) $upd['fecha_estado_propuesta'] = current_time('mysql');
                $wpdb->update($tabla_sol, $upd, array('id' => $solicitud_id));
                echo '<div class="updated notice"><p>Estado de propuesta actualizado: <strong>' . esc_html($nuevo_estado) . '</strong></p></div>';
            }
        } else {
            echo '<div class="error notice"><p>No se pudo cambiar el estado de la propuesta (falta columna <code>estado_propuesta</code> o datos inválidos).</p></div>';
        }
    }

    // =========================
    // GUARDAR (asignar proveedor + precio + comentario)
    // =========================
    if (isset($_POST['asignar_proveedor'])) {
        $solicitud_id = isset($_POST['solicitud_id']) ? intval($_POST['solicitud_id']) : 0;
        $estado       = isset($_POST['estado']) ? sanitize_text_field($_POST['estado']) : 'Pendiente';
        $menu_id      = isset($_POST['menu_id']) ? intval($_POST['menu_id']) : 0;

        $comentario_doc = isset($_POST['comentario_doc'])
            ? sanitize_textarea_field($_POST['comentario_doc'])
            : '';

        if ($solicitud_id > 0 && $menu_id > 0 && $tiene_menu_id) {

            $menu_row = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $tabla_men WHERE id = %d LIMIT 1", $menu_id),
                ARRAY_A
            );

            if ($menu_row && !empty($menu_row['proveedor_id'])) {
                $proveedor_id = (int)$menu_row['proveedor_id'];
                $precio_menu  = isset($menu_row['precio_menu']) ? $menu_row['precio_menu'] : '';

                $data_update = array(
                    'proveedor_id' => $proveedor_id,
                    'estado'       => $estado,
                );

                if ($precio_menu !== '' && $precio_menu !== null) {
                    if ($tiene_precio_menu)  $data_update['precio_menu']  = $precio_menu;
                    if ($tiene_menu_elegido) $data_update['menu_elegido'] = $precio_menu;
                }

                if ($tiene_comentario_doc) {
                    $data_update['comentario_doc'] = $comentario_doc;
                }

                $wpdb->update($tabla_sol, $data_update, array('id' => $solicitud_id));
                echo '<div class="updated notice"><p>Guardado correctamente.</p></div>';
            } else {
                echo '<div class="error notice"><p>No se encontró el menú seleccionado.</p></div>';
            }

        } else {
            echo '<div class="error notice"><p>No se pudo guardar: selecciona un menú.</p></div>';
        }
    }

    // =========================
    // LISTADO
    // =========================
    $solicitudes = $wpdb->get_results("SELECT * FROM $tabla_sol ORDER BY id DESC");

    // Rechazadas al final
    if (is_array($solicitudes)) {
        usort($solicitudes, function($a, $b) use ($tiene_estado_prop) {
            $ea = ($tiene_estado_prop && isset($a->estado_propuesta)) ? (string)$a->estado_propuesta : '';
            $eb = ($tiene_estado_prop && isset($b->estado_propuesta)) ? (string)$b->estado_propuesta : '';
            $wa = ($ea === 'Rechazada') ? 1 : 0;
            $wb = ($eb === 'Rechazada') ? 1 : 0;
            if ($wa === $wb) return 0;
            return ($wa < $wb) ? -1 : 1;
        });
    }

    ?>
    <div class="wrap">
        <h1>Gestión Catering Safor</h1>

        <style>
            .cscrm-actions{
                margin-top:8px;
                display:flex;
                gap:8px;
                align-items:center;
                flex-wrap:wrap;
            }

            /* ✅ misma línea siempre para los botones de acción */
            .cscrm-actions-line{
                margin-top:8px;
                display:flex;
                gap:8px;
                align-items:center;
                flex-wrap:nowrap;
            }
            .cscrm-actions-line form{ margin:0; }

            .cscrm-collapsible{ display:none; margin-top:10px; }
            .cscrm-collapsible.is-open{ display:block; }

            .cscrm-sharebar{
                margin-top:10px;
                display:flex;
                gap:8px;
                flex-wrap:wrap;
                align-items:center;
            }

            .cscrm-topbar{
                margin: 12px 0 16px;
                display:flex;
                gap:8px;
                flex-wrap:wrap;
                align-items:center;
            }

            .cscrm-menu-box{
                background:#fff;
                border:1px solid #dcdcde;
                border-radius:6px;
                padding:14px;
            }

            .cscrm-menu-box table{
                width:100%;
                border-collapse:collapse;
            }
            .cscrm-menu-box td{
                padding:7px 9px;
                border-top:1px solid #eee;
                vertical-align:top;
            }

            .cscrm-muted{ opacity:0.7; font-size:12px; line-height:1.3; }
            .cscrm-btn-viewsend{ white-space:nowrap; }

            .cscrm-comment{
                width:100%;
                height:34px;
                min-height:34px;
                max-height:120px;
                resize:none;
                overflow:hidden;
                box-sizing:border-box;
                margin-top:8px;
            }

            .cscrm-badge{
                display:inline-block;
                padding:2px 8px;
                border-radius:999px;
                font-size:12px;
                line-height:1.4;
                border:1px solid #dcdcde;
                background:#f6f7f7;
                margin-left:6px;
            }

            tr.cscrm-aceptada td{ background:#e9f7ee !important; }
            tr.cscrm-rechazada td{ background:#fff3e6 !important; }

            /* Documento */
            .cscrm-doc{
                position:relative;
                min-height: 960px;
                padding-bottom: 78px;
                box-sizing: border-box;
            }

            /* ✅ Footer una línea + sin saltos */
            .cscrm-doc-footer{
                position:absolute;
                left:0;
                right:0;
                bottom:0;
                padding-top:8px;
                border-top:1px solid #ddd;
                font-size:12px;
                display:flex;
                justify-content:space-between;
                gap:10px;
                flex-wrap:nowrap;
                white-space:nowrap;
            }

            /* ✅ bloque final compacto para que no empuje página extra */
            .cscrm-doc-bottom{
                margin-top:10px;
                font-size:12px;
                line-height:1.25;
                page-break-inside:avoid;
            }
            .cscrm-doc-bottom p{
                margin:6px 0;
            }

            @media print {
                .cscrm-topbar,
                .cscrm-sharebar,
                .cscrm-btn-viewsend,
                form { display:none !important; }

                table.widefat th:last-child,
                table.widefat td:last-child { display:none !important; }
            }
        </style>

        <?php if (!$tiene_estado_prop): ?>
            <div class="notice notice-warning">
                <p><strong>Falta:</strong> crea la columna <code>estado_propuesta</code> para usar Aceptada/Rechazada.</p>
            </div>
        <?php endif; ?>

        <!-- Botones globales listado -->
        <div class="cscrm-topbar">
            <button type="button" class="button button-primary cscrm-btn-print-list">🖨️ Imprimir listado</button>
            <button type="button" class="button cscrm-btn-share-list">📤 Compartir listado</button>
            <button type="button" class="button cscrm-btn-wa-list">💬 WhatsApp listado</button>
            <span class="cscrm-muted">Imprime/compartir solo el listado (sin la columna Gestión).</span>
        </div>

        <div id="cscrm-listado">
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>Evento</th>
                        <th>Fecha evento</th>
                        <th>Solicitud</th>
                        <th>Personas</th>
                        <th>Precio</th>
                        <th>Proveedor asignado</th>
                        <th>Gestión</th>
                    </tr>
                </thead>
                <tbody>

                <?php if (!$solicitudes): ?>
                    <tr><td colspan="8">No hay solicitudes.</td></tr>
                <?php else: ?>
                    <?php foreach ($solicitudes as $s): ?>

                        <?php
                        $precio = '';
                        if (!empty($s->precio_menu)) $precio = $s->precio_menu;
                        elseif (!empty($s->menu_elegido)) $precio = $s->menu_elegido;

                        $proveedor_nombre = '';
                        if (!empty($s->proveedor_id)) {
                            $proveedor_nombre = $wpdb->get_var(
                                $wpdb->prepare("SELECT nombre FROM $tabla_pro WHERE id = %d", (int)$s->proveedor_id)
                            );
                        }

                        $created_at_txt = $tiene_created_at ? $fmt_dt($s->created_at ?? '') : '';
                        $evento_dt_txt  = $tiene_evento_datetime ? $fmt_dt($s->evento_datetime ?? '') : '';

                        $servicios_map = array(
                            'camareros'   => 'Camareros',
                            'mesas'       => 'Mesas',
                            'sillas'      => 'Sillas',
                            'mesas_altas' => 'Mesas altas',
                            'manteria'    => 'Mantelería',
                            'cuberteria'  => 'Cubertería / Vajilla',
                        );
                        $servicios_sel = array();
                        foreach ($servicios_map as $campo => $label) {
                            if (isset($s->$campo) && intval($s->$campo) === 1) $servicios_sel[] = $label;
                        }
                        $servicios_txt = !empty($servicios_sel) ? implode(', ', $servicios_sel) : '';

                        $comentario_doc_actual = ($tiene_comentario_doc && isset($s->comentario_doc)) ? (string)$s->comentario_doc : '';

                        $estado_prop = ($tiene_estado_prop && isset($s->estado_propuesta)) ? (string)$s->estado_propuesta : '';
                        $row_class = ($estado_prop === 'Aceptada') ? 'cscrm-aceptada' : (($estado_prop === 'Rechazada') ? 'cscrm-rechazada' : '');

                        $precio_num = 0;
                        if ($precio !== '') {
                            $tmp = preg_replace('/[^\d,\.]/', '', (string)$precio);
                            $tmp = str_replace(',', '.', $tmp);
                            $precio_num = is_numeric($tmp) ? (float)$tmp : 0;
                        }

                        $menus = $wpdb->get_results(
                            $wpdb->prepare(
                                "SELECT m.id AS menu_id, m.proveedor_id, m.precio_menu, p.nombre
                                 FROM $tabla_men m
                                 LEFT JOIN $tabla_pro p ON p.id = m.proveedor_id
                                 ORDER BY ABS(m.precio_menu - %f) ASC",
                                $precio_num
                            )
                        );

                        // Menú asignado + id para selected
                        $menu_asignado = null;
                        $menu_asignado_id = 0;

                        if (!empty($s->proveedor_id) && $tiene_menu_id) {
                            if ($precio !== '') {
                                $menu_asignado = $wpdb->get_row(
                                    $wpdb->prepare(
                                        "SELECT * FROM $tabla_men WHERE proveedor_id=%d AND precio_menu=%s LIMIT 1",
                                        (int)$s->proveedor_id,
                                        (string)$precio
                                    ),
                                    ARRAY_A
                                );
                            }
                            if (!$menu_asignado) {
                                $menu_asignado = $wpdb->get_row(
                                    $wpdb->prepare("SELECT * FROM $tabla_men WHERE proveedor_id=%d LIMIT 1", (int)$s->proveedor_id),
                                    ARRAY_A
                                );
                            }
                            if ($menu_asignado && isset($menu_asignado['id'])) $menu_asignado_id = (int)$menu_asignado['id'];
                        }

                        $solicitud_id = (int)$s->id;
                        $panel_id = 'cscrm-panel-' . $solicitud_id;
                        $doc_id   = 'cscrm-doc-' . $solicitud_id;

                        $campos_ocultos = array('id', 'proveedor_id', 'disponible', 'available', 'activo');
                        ?>

                        <tr class="<?php echo esc_attr($row_class); ?>" data-row="<?php echo esc_attr($solicitud_id); ?>">
                            <td><?php echo esc_html($s->cliente); ?></td>

                            <td>
                                <?php echo esc_html($s->lugar_evento); ?>

                                <?php if (!empty($estado_prop)) : ?>
                                    <span class="cscrm-badge" data-badge="<?php echo esc_attr($solicitud_id); ?>"><?php echo esc_html($estado_prop); ?></span>
                                <?php else: ?>
                                    <span class="cscrm-badge" style="display:none;" data-badge="<?php echo esc_attr($solicitud_id); ?>"></span>
                                <?php endif; ?>

                                <?php if (!empty($servicios_txt)) : ?>
                                    <div class="cscrm-muted">Servicios adicionales: <?php echo esc_html($servicios_txt); ?></div>
                                <?php endif; ?>

                                <?php if (!empty($comentario_doc_actual)) : ?>
                                    <div class="cscrm-muted"><strong>Comentario:</strong> <?php echo esc_html($comentario_doc_actual); ?></div>
                                <?php endif; ?>
                            </td>

                            <td><?php echo $evento_dt_txt ? esc_html($evento_dt_txt) : '<span class="cscrm-muted">—</span>'; ?></td>
                            <td><?php echo $created_at_txt ? esc_html($created_at_txt) : '<span class="cscrm-muted">—</span>'; ?></td>

                            <td><?php echo esc_html($s->personas); ?></td>
                            <td><?php echo esc_html($precio); ?> €</td>

                            <td><?php echo $proveedor_nombre ? '<strong>' . esc_html($proveedor_nombre) . '</strong>' : '<em>No asignado</em>'; ?></td>

                            <td>
                                <!-- FORM guardar -->
                                <form method="post" class="cscrm-form-guardar" data-form="<?php echo esc_attr($solicitud_id); ?>">
                                    <input type="hidden" name="solicitud_id" value="<?php echo esc_attr($s->id); ?>">

                                    <select name="menu_id" required>
                                        <option value="">Asignar menú…</option>
                                        <?php if ($menus): ?>
                                            <?php foreach ($menus as $m): ?>
                                                <option value="<?php echo esc_attr($m->menu_id); ?>" <?php selected((int)$m->menu_id, $menu_asignado_id); ?>>
                                                    <?php echo esc_html($m->nombre); ?> (<?php echo esc_html($m->precio_menu); ?> €)
                                                </option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>

                                    <select name="estado">
                                        <option value="Pendiente" <?php selected($s->estado ?? '', 'Pendiente'); ?>>Pendiente</option>
                                        <option value="Asignada"  <?php selected($s->estado ?? '', 'Asignada');  ?>>Asignada</option>
                                        <option value="Cerrada"   <?php selected($s->estado ?? '', 'Cerrada');   ?>>Cerrada</option>
                                    </select>

                                    <textarea class="cscrm-comment" name="comentario_doc" rows="1"
                                        placeholder="Comentario para el cliente (se verá en el documento)..."
                                    ><?php echo esc_textarea($comentario_doc_actual); ?></textarea>

                                    <!-- ✅ Botones en misma línea (premium) -->
                                    <div class="cscrm-actions-line">
                                        <button class="button button-primary" name="asignar_proveedor">Guardar</button>

                                        <?php if (!empty($s->proveedor_id) && !empty($menu_asignado)): ?>
                                            <button type="button" class="button cscrm-btn-viewsend" data-panel="<?php echo esc_attr($panel_id); ?>">
                                                Ver y enviar
                                            </button>

                                            <?php if ($tiene_estado_prop): ?>
                                                <form method="post" class="cscrm-mini-form">
                                                    <input type="hidden" name="solicitud_id" value="<?php echo esc_attr($s->id); ?>">
                                                    <input type="hidden" name="nuevo_estado" value="Aceptada">
                                                    <button class="button button-secondary cscrm-btn-estado"
                                                        data-estado="Aceptada"
                                                        data-panel="<?php echo esc_attr($panel_id); ?>"
                                                        data-id="<?php echo esc_attr($solicitud_id); ?>"
                                                        name="cambiar_estado_propuesta"
                                                        onclick="return confirm('¿Marcar como ACEPTADA esta propuesta?');">
                                                        Aceptada
                                                    </button>
                                                </form>

                                                <form method="post" class="cscrm-mini-form">
                                                    <input type="hidden" name="solicitud_id" value="<?php echo esc_attr($s->id); ?>">
                                                    <input type="hidden" name="nuevo_estado" value="Rechazada">
                                                    <button class="button button-secondary cscrm-btn-estado"
                                                        data-estado="Rechazada"
                                                        data-panel="<?php echo esc_attr($panel_id); ?>"
                                                        data-id="<?php echo esc_attr($solicitud_id); ?>"
                                                        name="cambiar_estado_propuesta"
                                                        onclick="return confirm('¿Marcar como RECHAZADA esta propuesta?');">
                                                        Rechazada
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </form>

                                <?php if (!empty($s->proveedor_id) && !empty($menu_asignado)): ?>
                                    <div class="cscrm-collapsible" id="<?php echo esc_attr($panel_id); ?>">
                                        <div class="cscrm-menu-box cscrm-doc" id="<?php echo esc_attr($doc_id); ?>">

                                            <div style="text-align:center; margin-bottom:10px;">
                                                <?php if (!empty($cscrm_logo_url)): ?>
                                                    <div style="margin-bottom:6px;">
                                                        <img src="<?php echo esc_url($cscrm_logo_url); ?>"
                                                             alt="Catering Safor"
                                                             style="max-width:220px; width:100%; height:auto;">
                                                    </div>
                                                <?php endif; ?>
                                                <div style="font-size:20px; font-weight:700;">Catering Safor</div>
                                                <div style="font-size:13px; opacity:0.75;">Nuestra mejor oferta</div>
                                            </div>

                                            <div style="margin-bottom:8px; font-size:13px;">
                                                <div><strong>Evento:</strong> <?php echo esc_html($s->lugar_evento); ?></div>
                                                <?php if ($evento_dt_txt): ?>
                                                    <div><strong>Fecha y hora:</strong> <?php echo esc_html($evento_dt_txt); ?></div>
                                                <?php endif; ?>
                                                <div><strong>Personas:</strong> <?php echo esc_html($s->personas); ?></div>
                                            </div>

                                            <table>
                                                <tbody>
                                                <?php
                                                if (isset($menu_asignado['precio_menu']) && trim((string)$menu_asignado['precio_menu']) !== '') {
                                                    echo '<tr><td style="width:180px;"><strong>Precio</strong></td><td>' . esc_html($menu_asignado['precio_menu']) . ' €</td></tr>';
                                                }

                                                $nota_servicios_insertada = false;
                                                $bebidas_detectadas = false;

                                                foreach ($menu_asignado as $k => $v) {
                                                    $k_low = strtolower((string)$k);
                                                    if (in_array($k_low, $campos_ocultos, true)) continue;
                                                    if ($k_low === 'precio_menu') continue;
                                                    if ($v === null) continue;
                                                    $v_str = trim((string)$v);
                                                    if ($v_str === '') continue;

                                                    $label = (strtolower((string)$k) === 'nombre_menu')
                                                        ? 'Menú'
                                                        : ucwords(str_replace(array('_','-'), ' ', (string)$k));

                                                    echo '<tr>';
                                                    echo '<td style="width:180px;"><strong>' . esc_html($label) . '</strong></td>';
                                                    echo '<td>' . nl2br(esc_html($v_str)) . '</td>';
                                                    echo '</tr>';

                                                    if (!$bebidas_detectadas && ($k_low === 'bebidas' || strpos($k_low, 'bebida') !== false)) {
                                                        $bebidas_detectadas = true;
                                                    }

                                                    if ($bebidas_detectadas && !$nota_servicios_insertada && !empty($servicios_txt)) {
                                                        echo '<tr><td style="width:180px;"><strong>Servicios adicionales</strong></td><td>';
                                                        echo '<strong>Servicios adicionales no incluidos en el precio del menú.</strong><br>';
                                                        echo esc_html($servicios_txt);
                                                        echo '</td></tr>';
                                                        $nota_servicios_insertada = true;
                                                    }
                                                }

                                                if (!$nota_servicios_insertada && !empty($servicios_txt)) {
                                                    echo '<tr><td style="width:180px;"><strong>Servicios adicionales</strong></td><td>';
                                                    echo '<strong>Servicios adicionales no incluidos en el precio del menú.</strong><br>';
                                                    echo esc_html($servicios_txt);
                                                    echo '</td></tr>';
                                                }

                                                if (!empty($comentario_doc_actual)) {
                                                    echo '<tr><td style="width:180px;"><strong>Comentario</strong></td><td>' . nl2br(esc_html($comentario_doc_actual)) . '</td></tr>';
                                                }
                                                ?>
                                                </tbody>
                                            </table>

                                            <div class="cscrm-doc-bottom">
                                                <p><strong>Fecha de propuesta:</strong> <?php echo esc_html($cscrm_fecha_propuesta); ?></p>
                                                <p><strong>Validez:</strong> Esta propuesta es válida durante 15 días.</p>
                                                <p>Esperemos que sea de su agrado. Si le interesa confírmenos lo antes posible.</p>
                                            </div>

                                            <div class="cscrm-doc-footer">
                                                <div>🌐 cateringsafor.com</div>
                                                <div>📞 638 25 01 56</div>
                                                <div>💬 WhatsApp 638 25 01 56</div>
                                            </div>

                                        </div>

                                        <div class="cscrm-sharebar" data-doc="<?php echo esc_attr($doc_id); ?>">
                                            <button type="button" class="button button-primary cscrm-btn-print">🖨️ Imprimir</button>
                                            <button type="button" class="button cscrm-btn-share">📤 Compartir</button>
                                            <button type="button" class="button cscrm-btn-wa">💬 WhatsApp</button>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </td>
                        </tr>

                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <script>
        (function(){
            function closeAllExcept(id){
                document.querySelectorAll('.cscrm-collapsible.is-open').forEach(function(el){
                    if (el.id !== id) el.classList.remove('is-open');
                });
            }

            function togglePanel(id){
                var el = document.getElementById(id);
                if (!el) return;
                var willOpen = !el.classList.contains('is-open');
                if (willOpen){
                    closeAllExcept(id);
                    el.classList.add('is-open');
                    try { el.scrollIntoView({ behavior:'smooth', block:'nearest' }); } catch(e){}
                } else {
                    el.classList.remove('is-open');
                }
            }

            function printElement(el){
                if (!el) { alert('No se encontró el contenido.'); return; }
                var w = window.open('', '_blank', 'width=1000,height=700');
                if (!w) { alert('El navegador bloqueó la impresión. Permite pop-ups para esta web.'); return; }

                var html =
                  '<!doctype html><html><head><meta charset="utf-8"><title>Imprimir</title>' +
                  '<style>' +
                  'body{font-family:Arial,sans-serif;padding:18px;color:#111;}' +
                  'table{width:100%;border-collapse:collapse;}' +
                  'table,td,th{border:1px solid #ddd;}' +
                  'td,th{padding:8px;vertical-align:top;}' +
                  '.cscrm-doc{position:relative;min-height:960px;padding-bottom:78px;box-sizing:border-box;}' +
                  '.cscrm-doc-footer{position:fixed;left:18px;right:18px;bottom:14px;padding-top:8px;border-top:1px solid #ddd;font-size:12px;display:flex;justify-content:space-between;flex-wrap:nowrap;white-space:nowrap;}' +
                  'img{max-width:220px;height:auto;}' +
                  '</style>' +
                  '</head><body>' + el.outerHTML +
                  '<script>window.onload=function(){window.print();window.close();};<\/script>' +
                  '</body></html>';

                w.document.open(); w.document.write(html); w.document.close();
            }

            function getText(el){
                if (!el) return '';
                return (el.innerText || el.textContent || '').trim();
            }

            async function shareText(text){
                if (navigator.share){
                    try { await navigator.share({ title:'Catering Safor', text:text }); return; } catch(e){}
                }
                try{
                    await navigator.clipboard.writeText(text);
                    alert('Texto copiado al portapapeles ✅');
                }catch(e){
                    window.prompt('Copia el texto:', text);
                }
            }

            function autosizeComment(el){
                if (!el) return;
                el.style.height = '34px';
                var h = el.scrollHeight || 34;
                if (h > 34) el.style.height = Math.min(h, 120) + 'px';
            }

            document.querySelectorAll('.cscrm-comment').forEach(function(t){
                autosizeComment(t);
                t.addEventListener('input', function(){ autosizeComment(t); });
            });

            // ✅ Premium: cerrar panel + badge + color al instante (antes de recargar)
            function applyEstadoUI(id, estado){
                var row = document.querySelector('tr[data-row="'+id+'"]');
                if (row){
                    row.classList.remove('cscrm-aceptada','cscrm-rechazada');
                    if (estado === 'Aceptada') row.classList.add('cscrm-aceptada');
                    if (estado === 'Rechazada') row.classList.add('cscrm-rechazada');
                }
                var badge = document.querySelector('[data-badge="'+id+'"]');
                if (badge){
                    badge.style.display = 'inline-block';
                    badge.textContent = estado;
                }
            }

            document.addEventListener('click', function(ev){
                var btnView = ev.target.closest('.cscrm-btn-viewsend');
                if (btnView){
                    var panel = btnView.getAttribute('data-panel');
                    if (panel) togglePanel(panel);
                    return;
                }

                var btnEstado = ev.target.closest('.cscrm-btn-estado');
                if (btnEstado){
                    var estado = btnEstado.getAttribute('data-estado');
                    var panelId = btnEstado.getAttribute('data-panel');
                    var sid = btnEstado.getAttribute('data-id');

                    // UI inmediata
                    if (sid && estado) applyEstadoUI(sid, estado);

                    // Cerrar panel (premium)
                    if (panelId){
                        var el = document.getElementById(panelId);
                        if (el) el.classList.remove('is-open');
                    }
                    return; // el submit seguirá su curso
                }

                var btnPrint = ev.target.closest('.cscrm-btn-print');
                var btnShare = ev.target.closest('.cscrm-btn-share');
                var btnWa    = ev.target.closest('.cscrm-btn-wa');

                if (btnPrint || btnShare || btnWa){
                    var bar = ev.target.closest('.cscrm-sharebar');
                    if (!bar) return;

                    var docId = bar.getAttribute('data-doc');
                    var docEl = document.getElementById(docId);
                    if (!docEl) { alert('No se encontró el documento del cliente.'); return; }

                    var text = getText(docEl);

                    if (btnPrint){ printElement(docEl); return; }
                    if (btnShare){ shareText(text); return; }
                    if (btnWa){ window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank'); return; }
                }

                // Botones listado arriba
                var btnPL = ev.target.closest('.cscrm-btn-print-list');
                var btnSL = ev.target.closest('.cscrm-btn-share-list');
                var btnWL = ev.target.closest('.cscrm-btn-wa-list');

                if (btnPL || btnSL || btnWL){
                    var cont = document.getElementById('cscrm-listado');
                    if (!cont) return;

                    var clone = cont.cloneNode(true);
                    clone.querySelectorAll('table tr').forEach(function(tr){
                        var last = tr.querySelector('th:last-child, td:last-child');
                        if (last) last.remove();
                    });

                    var textList = getText(clone);

                    if (btnPL){ printElement(clone); return; }
                    if (btnSL){ shareText(textList); return; }
                    if (btnWL){ window.open('https://wa.me/?text=' + encodeURIComponent(textList), '_blank'); return; }
                }
            });

        })();
        </script>

    </div>
    <?php
}}
